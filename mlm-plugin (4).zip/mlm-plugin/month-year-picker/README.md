Monthpicker
===========

View examples and some doc [live](http://lucianocosta.github.io/jquery.mtz.monthpicker/).
