<?php
/**

 * plugin Name:       MLM Software
 * Description:       MLM software description
 * Version:           1.1.0
 * Author:            Expinator
 * Author URI:        https://expinator.com
 * Text Domain:       mlm-software
 * Domain Path:       /languages

 */

defined('ABSPATH') or die();
defined('MLM_PLUGIN')  or define('MLM_PLUGIN', plugin_dir_url(__FILE__));
defined('MLM_PLUGIN_PATH')  or define('MLM_PLUGIN_PATH', plugin_dir_path(__FILE__));
defined('MLM_PLUGIN_TEXTDOMAIN')  or define('MLM_PLUGIN_TEXTDOMAIN', 'mlm-plugin');
defined('MLM_PLUGIN_ASSETS_URL')  or define('MLM_PLUGIN_ASSETS_URL', MLM_PLUGIN . 'includes/assets/');
defined('MLM_PLUGIN_INCLUDE_PATH')  or define('MLM_PLUGIN_INCLUDE_PATH', MLM_PLUGIN_PATH . 'includes/');

add_action('plugins_loaded', 'mlm_plugin_check_woocommerce', -20);

if (!function_exists('mlm_plugin_check_woocommerce')) {
    function mlm_plugin_check_woocommerce()
    {
        if (current_user_can('activate_plugins') && !class_exists('WooCommerce')) {
            function wc_mlm_plugin_dependencies()
            {
                echo '<div class="error"><p>' . sprintf(__('The <strong>%s</strong> extension requires the Woocommerce plugin to be activated to work properly. You can download it <a href="https://wordpress.org/plugins/woocommerce/">here</a>', MLM_PLUGIN_TEXTDOMAIN), 'New payment Gateway') . '</p></div>';
                deactivate_plugins(plugin_basename(__FILE__));
            }
            add_action('admin_notices', 'wc_mlm_plugin_dependencies');
        }else {
            require_once MLM_PLUGIN_INCLUDE_PATH . 'core/class.mlm_plugin.php';
        }
    }
}

// $timestamp = wp_next_scheduled('bl_cron_hook');
// wp_unschedule_event($timestamp, 'bl_cron_hook');

// Schedule the cron event on plugin activation
// register_activation_hook(__FILE__, 'my_custom_plugin_activate');
// function my_custom_plugin_activate()
// {
//     if (!wp_next_scheduled('bl_cron_hook')) {
//         wp_schedule_event(time(), 'custom_minute', 'bl_cron_hook');
//     }
// }

// // Unschedule the cron event on plugin deactivation
// register_deactivation_hook(__FILE__, 'my_custom_plugin_deactivate');
// function my_custom_plugin_deactivate()
// {
//     $timestamp = wp_next_scheduled('bl_cron_hook');
//     wp_unschedule_event($timestamp, 'bl_cron_hook');
// }

// // Function to add custom intervals
// add_filter('cron_schedules', 'my_custom_cron_intervals');
// function my_custom_cron_intervals($schedules)
// {
//     $schedules['custom_minute'] = array(
//         'interval' => 60, // 1 minute in seconds
//         'display'  => __('Custom Minute'),
//     );
//     return $schedules;
// }

// // Function to be executed by the cron job
// add_action('bl_cron_hook', 'bl_cron_exec');
// function bl_cron_exec()
// {
//     // Your code to send an email goes here
//     // For example:
//     wp_mail('recipient@example.com', 'Cron Job Execution', 'This email was sent by the cron job.');
// }


// function getLastDayOfMonth($year, $month) {
//     // Set the date to the first day of the next month
//     $firstDayOfNextMonth = date("Y-m-d", strtotime("$year-$month-01 +1 month"));

//     // Subtract 1 day from the first day of the next month to get the last day of the current month
//     $lastDayOfMonth = date("d", strtotime("$firstDayOfNextMonth -1 day"));

//     return $lastDayOfMonth;
// }

// // Example usage:
// $year = 2024;
// $month = 2; // July

// $lastDay = getLastDayOfMonth($year, $month);
// echo $lastDay; // Output: 31



// Hook the custom cron job to a specific action
// add_action('my_custom_cron_hook', 'my_custom_cron_functionfff');

// function my_custom_cron_functionfff() {
//     // Your code to be executed by the cron job
//     // Replace this with your actual code
//     wp_mail('test@gmail.com','test','test');
//     // error_log('Custom cron job executed at ' . current_time('mysql'));
// }

// // Activate the plugin
// register_activation_hook(__FILE__, 'activate_custom_cron_plugin');

// function activate_custom_cron_plugin() {
//     // Schedule the custom cron job to run every hour
//     if (!wp_next_scheduled('my_custom_cron_hook')) {
//         wp_schedule_event(time(), 'every_minute', 'my_custom_cron_hook');
//     }
// }

// // Deactivate the plugin
// register_deactivation_hook(__FILE__, 'deactivate_custom_cron_plugin');

// function deactivate_custom_cron_plugin() {
//     // Clear the scheduled cron job on plugin deactivation
//     wp_clear_scheduled_hook('my_custom_cron_hook');
// }


// // Add a custom interval for every minute
// add_filter('cron_schedules', 'add_custom_minute_interval');

// function add_custom_minute_interval($schedules) {
//     $schedules['every_minute'] = array(
//         'interval' => 60, // 60 seconds, which is 1 minute
//         'display'  => __('Every Minute')
//     );
//     return $schedules;
// }





