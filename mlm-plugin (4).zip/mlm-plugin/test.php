<?php

require_once 'vendor/autoload.php';

	// echo plugin_dir_path( __FILE__ ) . 'vendor/autoload.php';
	// die;
	
	
	$pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);
	$pdf->SetCreator(PDF_CREATOR);
	$pdf->SetAuthor('Your Name');
	$pdf->SetTitle('Sample PDF');
	$pdf->SetSubject('Generating PDF in PHP');
	$pdf->SetKeywords('PDF, TCPDF, PHP, example');
	
	$pdf->AddPage();

	
	$pdf->SetFont('helvetica', 'B', 16);
	$pdf->Cell(0, 10, 'Hello, World!', 0, 1, 'C');
	
	// Add more content as needed
	
	$pdf->Output('sample.pdf', 'D');
