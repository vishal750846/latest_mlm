<?php //end file of wordpress ?>
