<?php ?>    
<div class="overlay" style="display:none;">
  <div class="loader"></div>
</div>
<!--  -->
<div class="cont-div">
    <b>If you are not already a customer, select a referrer/sponsor either a school or individual.</b>
    <p>If a friend or colleague introduced you to the New Nation Education NPO then click on the "Who is your Sponsor" button, find their <b>user</b> name in the table and select them from the table, continue with registration. If you were introduced to the New Nation Education NPO buy a school and would like to sponsor a school, then click on the "Who is your Sponsor" button, a list of the registered schools will appear, find their <b>user</b> name, select them and continue with registration. <b>If the school name is not</b> on the list or registered, kindly click on the contact us TAB at the top of the screen and send us a comment, with the schools name and phone number and we will get them registered so that you can select them as your sponsor.</p>
    </div>
      <form method="post" id="register_form">
        <div>
        <label for="username">User Name<sup>*</sup></label>
        <input type="text" id="username" name="username">
    </div>
    
    <div>
        <label for="email">Email Address<sup>*</sup></label>
        <input type="email" id="email" name="email">
        </div>
    
        <div>
        <label for="fname">First Name<sup>*</sup></label>
        <input type="text" id="fname" name="fname">
        </div>
    
        <div>
        <label for="lname">Last Name<sup>*</sup></label>
        <input type="text" id="lname" name="lname">
        </div>
    
        <div>
        <label for="customer_type">Customer Type<sup>*</sup></label>
      <select name="customer_type" id="customer_type">
      <option value="">select one</option>
      <option value="P" >Employed</option>
      <option value="B">Business-School-Club or Society</option>
      <option value="U">Unemployed</option>
      <option value="S">Student</option>
    </select><br>
    </div>
    
    <div>
    <label for="your_sponsor">Who is your SPONSOR<sup>*</sup></label>
    <select name="your_sponsor" id="your_sponsor">
        <option value=""></option>
    </select><br>
 
    <input type="checkbox" name="terms" value="1" id="terms">
    <a href="https://gwcorp.co.za/terms-and-conditions/" target="_blank"><label class="term-label" for="check"> Accept Terms and Conditions <sup>*</sup></label></a>
     
    <?php $num1 = rand(1,20);
    $num2 = rand(1,20);?>
    <p><?php echo $num1;?>+<?php echo $num2;?></p>
      <input type="text" name="answer" id="answer">
      </div>

      <div>
      <input type="hidden" value="<?php echo $num1+$num2;?>" name="answer_result" id="answer_result">
      </div>
    
    <div class="register-part">
      <button type="submit" class="registerbtn" id="registerbtn">Register</button>
    </div>
      </form>

      <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
