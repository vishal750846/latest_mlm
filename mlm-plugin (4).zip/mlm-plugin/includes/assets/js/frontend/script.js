

jQuery(document).ready (function () {  
  jQuery.validator.addMethod("noSpace", function(value, element) { 
return value.indexOf(" ") < 0 && value != ""; 
}, "No space please and don't leave it empty");

jQuery.validator.addMethod("lettersonly", function(value, element) {
  return this.optional(element) || /^[a-z]+$/i.test(value);
}, "Letters only please"); 


  jQuery("#register_form").validate({
      rules:{
             username:{
                 required:true,
                 minlength:2,
                 noSpace: true
             },
               email:{
                  required:true,
                  email:true,
                 noSpace: true
              },
             fname:{
                 required:true,
                 noSpace: true ,
                 minlength:2,
                 lettersonly: true 
             },
             lname:{
                 required:true,
                 minlength:2,
                 noSpace: true,
                 lettersonly: true  
             },
             customer_type:{
                 required:true
             },
             terms: {
                  required : true
             },
             answer:{
                  required:true,
                  equalTo: "#answer_result"
             }
      },

      submitHandler: function (form) {

          var answer = $('#answer').val();
          var formData = new FormData();
          //console.log(formData);
  
  var serializeData=jQuery('#register_form').serialize();
  //console.log(serializeData);

  formData.append('action','register_form_action');
  formData.append('info',serializeData);
  //
  $(".overlay").show();
  //
  $.ajax({
      type: "POST",
          url: frontendajax.ajaxurl,
          data: formData,
          contentType: false,
          processData: false,

          // success: function (data) {
          //     if(data==2){
          //       alert('E-mail already exist');
          //     }
          //     else if (data == 3){
          //       alert("user name already exist");
          //     }
          //     else if (data == 1){
          //       alert("User registered successfully")
          //     }
          //     else{
          //       alert("Error occured, try after some time")
          //     }
          // }
          //
          success: function (data) {
          if(data == 2){
            $(".overlay").hide();
            Swal.fire({
              icon: 'error',
              title: 'Oops...',
              text: 'E-mail Already Exist'           
            })
         }
         else if (data == 3){
                $(".overlay").hide();
                Swal.fire({
                  icon: 'error',
                  title: 'Oops...',
                  text: 'User Name Already Exist'               
                })
              }
              else if (data == 1){
                $(".overlay").hide();
                // Swal.fire({
                //   position: 'top-end',
                //   icon: 'success',
                //   title: 'User registered successfully',
                //   showConfirmButton: false,
                //   timer: 1500
                // })
                Swal.fire({
                  icon: 'success',
                  position: 'center',
                  title: 'User Registered Successfully',
                    showConfirmButton: false,
                    timer: 1500               
                })
            // location.reload(true)
              }
              else{
                $(".overlay").hide();
                Swal.fire({
                  icon: 'error',
                  title: 'Oops...',
                  title: 'Error Occured, Try After Some Time'         
                })
                
              }
        //  else{
        //     alert("successfully submit");
        //     $(".overlay").hide();

        //     location.reload(true)
        //  }
        }


          //
  })


      }


  })


})

jQuery(document).ready(function($){  
$(document).on('change','#customer_type', function() {  

var customer_type = $("#customer_type").val(); 

$.ajax({
type: "POST",
dataType : "json",
 url: frontendajax.ajaxurl,
 data : {action: "sponsor_list_action", type : customer_type},
success:function(response){ 
  $("#your_sponsor").empty();
    // $("#your_sponsor").append('<option value="0">Select your Sponsor</option>');
  response.forEach(function (v, i) {
    $("#your_sponsor").append('<option value="'+v.value+'">'+v.option+'</option>');

  });

}
});




});
});