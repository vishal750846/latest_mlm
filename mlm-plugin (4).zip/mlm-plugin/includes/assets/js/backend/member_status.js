jQuery(document).ready(function($){  

	$(".notice").hide();
	
	$('#status_table_submit').click(function(){ 

		var level_percent = new Array();
			status_name = new Array();
			level_count = new Array();

		$('#member_status tr').each(function() {

			var row=$(this);
			var class_row= $(this).attr('class');

			if(class_row == "status_level"){
				row.find('td').each(function() {
					if( $(this).attr('class') == "status_level_name"){
						status_name.push($(this).text());							
					}
				});		 
			}else if(class_row == "level_count"){ 
				row.find('td').each(function() {
					if( $(this).attr('class') == "count"){ 
						level_count.push($(this).text());							
					}
				}); 	 
			}else if(class_row == "percent"){
				var percent = new Array();
				row.find('td').each(function() {
					if( $(this).attr('class') == "sel"){
						var val = $(this).find("select").val();
						percent.push(val);
					}
				});
				level_percent.push(percent);	
			}
		});

		var member_status = {};  
		for (var i = 0; i < status_name.length; i++){ 
		    member_status[status_name[i]] = level_count[i];
		}

		$.ajax({
			type: "POST",
			dataType : "json",
			url : frontendajax.ajaxurl,
		 	data : {action: "member_status_action", level : level_percent, status_level : member_status},
			success:function(response){ 
				if(response == "true") $(".notice").show();

			}
		});
	});


	$(".notice").hide();	
	$('#reward_table_submit').click(function(){


		// alert("ffgfgfggf");
		// return
		var level_percent = new Array();
			status_name = new Array();
			level_count = new Array();

		$('#reward_table tr').each(function() {
			var row=$(this);
			var class_row= $(this).attr('class');

			if(class_row == "reward_level"){
				row.find('td').each(function() {
					if( $(this).attr('class') == "reward_level_name"){
						status_name.push($(this).text());						
					}
				});		 
			}else if(class_row == "level_count"){ 
				row.find('td').each(function() {
					if( $(this).attr('class') == "count"){ 
						level_count.push($(this).text());						
					}
				}); 	 
			}else if(class_row == "percent"){
				var percent = new Array();
				row.find('td').each(function() {
					if( $(this).attr('class') == "sel"){
						var val = $(this).find("select").val();
						percent.push(val);
					}
				});
				level_percent.push(percent);	
			}
		});

		var member_status = {};  
		for (var i = 0; i < status_name.length; i++){ 
		    member_status[status_name[i]] = status_name[i];
		}

		// console.log(member_status)
		// // console.log(member_status)
		// // console.log(level_percent)
		// return
		

		$.ajax({
			type: "POST",
			dataType : "json",
			url : frontendajax.ajaxurl,
		 	data : {action: "reward_table_action", level : level_percent, status_level : member_status},
			success:function(response){
				console.log(response);
				return false;
				if(response == "true") $(".notice").show();
			}
		}); 

	});

});



