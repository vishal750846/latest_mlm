
jQuery(document).ready(function($){  
	var customer_type = $('#customer_type').val(); 


$(document).on('change','#customer_type', function() { 
	var customer_type = $('#customer_type').val();
	var user = $('#user_login').val();
	$.ajax({
		type: "POST",
        	dataType : "json",
         	url : "https://gwcorp.co.za/gw/wp-admin/admin-ajax.php",
         	data : {action: "profile_sponsor_list_action", type : customer_type, flag : "2", user : "0"},
		success:function(response){ 
			$("#your_sponsor").empty();
			response.forEach(function (v, i) {
				$("#your_sponsor").append('<option value="'+v.value+'">'+v.option+'</option>');
			});

		}
	});

	$.ajax({
		type: "POST",
        	dataType : "json",
         	url : "https://gwcorp.co.za/gw/wp-admin/admin-ajax.php",
         	data : {action: "profile_extra_action", type : customer_type, user : user},
		success:function(response){ 
			$("#expiry_date").val(response.date);
			$("#member_status").val(response.status);
		}
	});




});

$(document).on('change','#test_trigger', function() {

	var customer_type = $('#customer_type').val();
	var user = $('#user_login').val();
	if(customer_type != ""){
	$.ajax({
		type: "POST",
        	dataType : "json",
         	url : "https://gwcorp.co.za/gw/wp-admin/admin-ajax.php",
         	data : {action : "profile_sponsor_list_action", type : customer_type, flag : "1", user : user},
		success:function(response){ 
			$("#your_sponsor").empty();
			response.forEach(function (v, i) {
				$("#your_sponsor").append('<option value="'+v.value+'">'+v.option+'</option>');

			});
		}
	});
	}

});
$("#test_trigger").trigger('change');

});
