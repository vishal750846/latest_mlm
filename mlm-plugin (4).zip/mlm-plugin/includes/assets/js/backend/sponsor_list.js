jQuery(document).ready(function($){  
	$(document).on('change','#customer_type', function() {  

		var customer_type = $("#customer_type").val(); 
	
		$.ajax({
			type: "POST",
			dataType : "json",
		 	url : frontendajax.ajaxurl,
		 	data : {action: "sponsor_list_action", type : customer_type},
			success:function(response){ 
				$("#your_sponsor").empty();
					// $("#your_sponsor").append('<option value="0">Select your Sponsor</option>');
				response.forEach(function (v, i) {
					$("#your_sponsor").append('<option value="'+v.value+'">'+v.option+'</option>');

				});

			}
		});




	});
});



