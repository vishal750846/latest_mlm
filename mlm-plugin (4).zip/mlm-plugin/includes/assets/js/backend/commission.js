jQuery(document).ready(function($){  

// Enable or disable download button based on customer selection  19-9-23
$('#customer').on('change', function () {
	if ($(this).val() !== "0") {
		$('#downloadButton').prop('disabled', false);
		// alert('select a customererrr')
	} else {
		// alert('select a customer')
		$('#downloadButton').prop('disabled', true);
	}
});

// $('#downloadButton').on('click', function (e) {
// 	if ($('#customer').val() === "0") {
// 		e.preventDefault(); // Prevent the default form submission
// 		// Swal.fire('Any fool can use a computer')
// 		// alert("Please select a customer first.");
// 	}
// });
////****** */


	$(".my_select_box").chosen({
		disable_search_threshold: 10,
	   	 no_results_text: "Oops, nothing found!",
	   	 width: "25%",
	
		
	});
	
 	$('input[name="daterange"]').daterangepicker();
	 $('input[name="daterange"]').on('apply.daterangepicker', function(ev, picker) {

		var from = picker.startDate.format('YYYY-MM-DD');
		var to = picker.endDate.format('YYYY-MM-DD');
		var customer = $('#customer').val();
		var link = $("[name='downR']").attr("href"); 
		$("[name='downR']").attr("href", link+'?downloadR=commissionreport'+'&customer='+customer+'&from='+from+'&to='+to);

 	 });
	///$("[name='downR']").click(function() { alert('hi');
		//var customer = $('.my_select_box').val();
		//var from = picker.startDate.format('YYYY-MM-DD');
		//var to = picker.endDate.format('YYYY-MM-DD');  alert('customer'+customer); alert('from'+from); alert('to'+to);
		/*var link = $("[name='downR']").attr("href"); 
		$("[name='down']").attr("href", link+'?downloadR=commissionreport'+'&customer='+customer+'&from='+from+'&to='+to);
		alert($("[name='downR']").attr("href"));*/

	///});

	// jQuery(".loader_div").hide();
	// 	jQuery("#downloadButton").on('click',function(){
	// 		jQuery(".loader_div").show();
	// 	});

		
//

 // Add a click event to show an alert if the "Download" button is clicked without a customer selection

//

});



