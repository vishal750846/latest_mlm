

jQuery(document).ready(function($){  
	var find_length = function (start) {
		var length = 0;		
		if ($(start).find('ul').length > 0) {
			$(start).find('ul').each(function () {
				var t_length = find_length(this);
				if (! isNaN(t_length) && t_length > length) length = t_length;
			});
		}
    		else return 1;
		return length + 1;
	};



   
	$(".my_select_box").chosen({
		disable_search_threshold: 10,
	   	 no_results_text: "Oops, nothing found!",
	   	 width: "100%",


	});
	
	$('.my_select_box').on('change', function() { 
		
		var user = $(this).val(); 
		$.ajax({
			type: "POST",
			dataType : "json",
			url : frontendajax.ajaxurl,
		 	data : {action: "genealogy_action", user : user},
			success:function(response){  
				var levels = response.levels;
				var details = response.details; 
				var logged_in = "admin";
				var constant = 0;			
				var html = makeMarkUp(levels,details,logged_in,constant);
				$('.start').html('');
				$('.start').html(html);
				
				var width = parseInt(parseInt($('.start').css('paddingLeft')) + $('.content-div ').width() * find_length('.clt') - 1);
				if (width < $(document).width()) width = '100%';
				else width = width + 'px';
				$('.clt').css('width', width);
				$('.clt-row').css('width', width);
			}
		});

  	});


	$(document).on('change','#ad_gen_trigger', function() { 

		var user = $("#ad_gen_trigger").val(); 
		$.ajax({
			type: "POST",
			dataType : "json",
			url : frontendajax.ajaxurl,
		 	data : {action: "genealogy_action", user : user},
			success:function(response){ 
				var levels = response.levels;
				var details = response.details; 
				var logged_in = "admin";
				var constant = 1;
				var html = makeMarkUp(levels,details,logged_in,constant);

					$('.start').html(html);
				var width = parseInt(parseInt($('.start').css('paddingLeft')) + $('.content-div ').width() * find_length('.clt') - 1);
				if (width < $(document).width()) width = '100%';
				else width = width + 'px';
				$('.clt').css('width', width);
				$('.clt-row').css('width', width);




			}
		});

	});
	$("#ad_gen_trigger").trigger('change');

/***********distributer genealogy*****************/



	$(document).on('change','#gen_trigger', function() {  

		var user = $("#gen_trigger").val(); 
		$.ajax({
			type: "POST",
			dataType : "json",
			url : frontendajax.ajaxurl,
		 	data : {action: "genealogy_action", user : user},
			success:function(response){  
				var levels = response.levels;
				var details = response.details; 
				var logged_in = "notadmin";
				var constant = 0;
				var html = makeMarkUp(levels,details,logged_in,constant);

					$('.start').html(html);
				var width = parseInt(parseInt($('.start').css('paddingLeft')) + $('.content-div ').width() * find_length('.clt') - 1);
				if (width < $(document).width()) width = '100%';
				else width = width + 'px';
				$('.clt').css('width', width);
				$('.clt-row').css('width', width);




			}
		});

	});
	$("#gen_trigger").trigger('change');

	


/***********distributer genealogy*****************/



	/*$('#download').on('click', function() { 
		var user =  $('#ad_gen_trigger').val();
		$.ajax({
			type: "POST",
			dataType : "json",
			url : frontendajax.ajaxurl,
		 	data : {action: "csv_action", user : user},
			success:function(response){  
				alert(response);


			}
		});

	
	});*/



	$('#download').click(function() {
		$("#download-div").show();
	});

	$('#picker').monthpicker();

	$("#picker").change(function() {  

		//var val = $('#picker').val(); 
		//var link = $("[name='down']").attr("href"); 
		//$("[name='down']").attr("href", link+'?download_gen='+val);
 
		$('.blink').show();
		blink('.blink');
	})
	$("[name='down']").click(function() {
		var val = $('#picker').val(); 
		var link = $("[name='down']").attr("href"); 
		 var name = jQuery('.chosen-single').children('span').text() //19-9-23
		 var nameid =jQuery('.my_select_box').find(":selected").val();
		link = link.substring(0, link.lastIndexOf('?') !== -1 ? link.lastIndexOf('?') : link.length) + '?' + 'download_gen='+val  + "&name="+name + "&nameid="+nameid;
		// +val  + "&name="+name
		//$("[name='down']").attr("href", link+'?download_gen='+val);
		$("[name='down']").attr("href", link);
	});

});



function makeMarkUp(levels,details,logged_in,constant) {  

	
		var genObject = levels;
		var html = '';
		var level = 1; 
		for (var key in genObject) { 
    			if (genObject.hasOwnProperty(key)) {
			
				var sponsor = key;
				var users = genObject[key];
				html += gRender(level,sponsor,users,true, users.length == 0, true, details,logged_in,constant);
			}

		} 
	
	return html;
}


function userEdit(userId){ 

	window.open("https://gwcorp.co.za/gw/wp-admin/user-edit.php?user_id="+userId);
}

function changeNode(userId) { 
	jQuery("#ad_gen_trigger").val(userId).trigger('change');
	//$("#ad_gen_trigger").val(userId);
}


function gRender(level, sponsor, users, last, end_child, first_child, details,logged_in,constant) {  
	 var bgcolor = "";
    last = typeof last === 'boolean' ? last : false;
    var thisElement = '<li '+(last === false && first_child === true ? ' class="has-more-children"' : '')+'>';

    if( (logged_in == "admin") && ( constant == 0)){
     thisElement += '<div onclick="userEdit(\''+sponsor+'\')" class="content-div '+(end_child === true ? 'end-child' : '')+'">';
    }else if( (logged_in == "admin") && ( constant == 1)){
     thisElement += '<div onclick="changeNode(\''+sponsor+'\')" class="content-div '+(end_child === true ? 'end-child' : '')+'">';
    }else{

     thisElement += '<div class="content-div '+(end_child === true ? 'end-child' : '')+'">';
    }



var username = '', customerid = '', customertype = '', level = '', status = '';

if (details.constructor === Array)

details.forEach(function( val, index ) {

    for (var i in val) { 
       if(val.id == sponsor)
	{  
		username = val.username;
		customerid = val.id;
		customertype = val.type;
		level = val.level;
		status = val.status;

		console.log(customerid+"dddd"+status);
		
		switch (status){
			case "Active":
				bgcolor = "#2eb82e";
				break;
			case "Qualified":
				bgcolor = "#00b8e6";
				break;
			case "Inactive":
				bgcolor = "#ff9900";
				break;
			case "Terminated":
				bgcolor = "#cc0000";
				break;
			default:
				bgcolor = "#a6a6a6";		
				break;	

		}
		
	}
    }
});
  


    thisElement += '<div class="gen-block-header" style="background-color:'+bgcolor+';"><b>'+username+'</b></div><div class="gen-block-content" style=" width:100%; height:80%; background-color:white;"><span class="gen-details" >Username:'+username+'</span> </br> <span class="gen-details" >Customer Id:'+customerid+'</span></br><span class="gen-details" >Customer Type:'+customertype+'</span></br><span class="gen-details" >Membership Level:'+level+'</span></br><span class="gen-details">Customer Status:'+status+'</span></br></div>';

// thisElement += 'User '+sponsor;
    thisElement += '</div>';
    var last_child = null;
    first_child = null;
    for (var k in users) {
        last_child = k;
        first_child = first_child == null ? k : first_child;
    }
    thisElement += '<ul>';
    for (var k in users) {
        if(users.hasOwnProperty(k)){
            var eachUserKey = k;
            var sponsers1 = users[k];
            thisElement += gRender(level+1, eachUserKey, sponsers1, last_child == k, sponsers1.constructor == Array, first_child == k, details,logged_in,constant);
        }
    }
    thisElement += '</ul></li>';
    return thisElement;
}

function blink(selector){
	$(selector).fadeOut('slow', function(){
	    $(this).fadeIn('slow', function(){
		blink(this);
	    });
	});
}
function display_picker(){
	document.getElementById('download-div').style.display='none';
}

////