$("input[name='select_number']").on('change',function(){
    if($(this).val() == "no")
       $('.box').show('slow');
    else
        $('.box').hide();
});
// function getit() {
//     var select = document.getElementById('f06_w01').checked;
//     if (select == 1 || select == 3) {
//       document.getElementById('whitch').style.display = "block";
//     } else {
//       document.getElementById('whitch').style.display = "none";
//     }
//   }