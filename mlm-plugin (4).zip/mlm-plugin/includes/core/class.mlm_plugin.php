<?php

global $mlm_plugin_load_files;

class mlm_plugin_load_files
{

    public function __construct()
    {
        add_action('init', array($this, 'init_wc_sdp'));
        // add_action("init", array($this, 'shabaas_permalinks'));
        // add_filter("query_vars", array($this, "hss_query_vars"));
        // add_action("template_include", array($this, 'hss_static_templates'));
        // add_action('woocommerce_loaded', array($this, 'load_wcsdp'));
    }
    public function init_wc_sdp()
    {
        load_theme_textdomain(MLM_PLUGIN_TEXTDOMAIN, false, basename(dirname(__FILE__)) . '/languages');
        // // wp_enqueue_style('print_node-frontend-style',  NEW_PAYMENT_GATEWAY_ASSETS_URL . "css/frontend/style.css", false, time(), false);
        require MLM_PLUGIN_INCLUDE_PATH . 'core/class.mlm_backend.php';
        require MLM_PLUGIN_INCLUDE_PATH . 'core/class.mlm_frontend.php';
        require MLM_PLUGIN_INCLUDE_PATH . 'core/ajax-actions.php';
    }
}


$mlm_plugin_load_files = new mlm_plugin_load_files();

