<?php
// function customize_phpmailer_for_gmail($mail) {
// 	$mail->isSMTP(); //Send using SMTP
//     $mail->Host       = 'smtp.gmail.com'; //Set the SMTP server to send through
//     $mail->SMTPAuth   = true;
// 	$mail->Username   = 'aditi.a.expinator@gmail.com'; //SMTP username
//     $mail->Password   = 'dcyqxlgljvheomlr';
// 	$mail->SMTPSecure = 'tls';
//     $mail->Port = 587;
// }
// add_action('phpmailer_init', 'customize_phpmailer_for_gmail');

add_action('wp_ajax_register_form_action','register_form_action');
add_action('wp_ajax_nopriv_register_form_action','register_form_action');

function register_form_action(){
    $formdata = array();
    parse_str($_POST['info'], $formdata); 

    $username = $formdata['username'];
    $email = $formdata['email'];
    $fname = $formdata['fname'];
    $lname = $formdata['lname'];
    $customer_type = $formdata['customer_type'];
    $your_sponsor = $formdata['your_sponsor'];
    $terms = $formdata['terms'];
	$passwordGenerate=wp_generate_password( 15, true, true );

	$emailExists = email_exists( $email );
	$usernameExists=username_exists( $username );

	if($emailExists){
        echo 2;
		wp_die();
	}
	if($usernameExists){
        echo 3;
		wp_die();
	}

	$userdata = array(
		'user_login' =>  $username,
		'user_email' =>  $email, 	
		'first_name' =>  $fname, 	
	    'last_name'  =>  $lname,
		'role' 		 =>  'customer',
		'user_pass'	 =>  $passwordGenerate, 
	);
	
	$user_id = wp_insert_user( $userdata ) ;
	
	// On success.
	if ( ! is_wp_error( $user_id ) ) {
		// echo "User created : ". $user_id;

	if ( ! empty($your_sponsor) ) { 
		update_user_meta( $user_id, 'your_sponsor', trim( $your_sponsor ) );

	 }
 $user_details = get_userdata( $user_id );
 if( (!empty( $customer_type ) )){	
	switch($customer_type){

		 case "P": 
			 $days =  get_option('custom_profile_op_exp_date_P');
			 $expiry_date = date('Y-m-d',strtotime($user_details->user_registered) + (24*3600*$days));

			 $member_status = get_option('custom_profile_op_member_status_P');
			 break;
		 case "B": 
			 $days =  get_option('custom_profile_op_exp_date_P');
			 $expiry_date = date('Y-m-d',strtotime($user_details->user_registered) + (24*3600*$days));

			 $member_status = get_option('custom_profile_op_member_status_P');
			 break;

		 case "S": 
			 $days =  get_option('custom_profile_op_exp_date_S');
			 $expiry_date = date('Y-m-d',strtotime($user_details->user_registered) + (24*3600*$days));
			 $member_status = get_option('custom_profile_op_member_status_S');
			 break;
		 case "U": 
			 $days =  get_option('custom_profile_op_exp_date_U');
			 $expiry_date = date('Y-m-d',strtotime($user_details->user_registered) + (24*3600*$days));
			 $member_status = get_option('custom_profile_op_member_status_U');
			 break;
		 default:
			 break;
	 }


	    $subject="Welcome Email";
		$message="<p>Hello ".$fname." ".$lname."</p><br>We have successfully registered your application. Your Password is : <strong>". $passwordGenerate."</strong><br>Thanks";
		$headers = array( 'Content-Type: text/html; charset=UTF-8' );
		// use wordwrap() if lines are longer than 70 characters

	    wp_mail($email,$subject,$message,$headers);
//   if( $retval == true ) {
// 	 echo "Message sent successfully...";
//   }else {
// 	 echo "Message could not be sent...";
//   }
		 update_user_meta($user_id, 'expiry_date', $expiry_date);
		 update_user_meta($user_id, 'membership_level', 'Bronze');
		 update_user_meta($user_id, 'member_status', $member_status);
		 update_user_meta($user_id, 'genealogy_level', '3');
		 update_user_meta($user_id, 'customer_type', $customer_type);
		 update_user_meta( $user_id, 'reward_level', '1');
		 update_user_meta( $user_id, 'consecutive_months', '0');
		}
		echo 1;
		wp_die();
}
else{
	echo 0;
	wp_die();
}
}

// This function will be triggered when a user attempts to log in
function custom_restrict_user_login( $user ) {
    // Get the user ID
    $user_id = $user->ID;
    $user = get_user_by( 'id', $user_id );
   
    // Check if the user meta status is set to 'Terminated' for this user
    $restricted_status = get_user_meta( $user_id, 'member_status', true );

    // You can change 'restricted_status' to the actual user meta key where you store the status
    if ( $restricted_status === 'Terminated' ) {      
        $error_message = 'Your account has been restricted from logging in.';
        return new WP_Error( 'login_failed', $error_message );	
    }
    return $user;
}
add_filter( 'wp_authenticate_user', 'custom_restrict_user_login' );

/*Ajax function to list sponsors in registration page - starts*/
add_action( 'wp_ajax_sponsor_list_action', 'sponsor_list_action' );
add_action( 'wp_ajax_nopriv_sponsor_list_action', 'sponsor_list_action' ); 
function sponsor_list_action() {
	$customer_type = $_POST['type'];
	global $wpdb;
	$sponsor_list_1 = array();
	$sponsor_list_2 = array();
	foreach ( $wpdb->get_results("SELECT ID, user_login, display_name FROM $wpdb->users ORDER BY user_login") as $user ) :
		$user_id = $user->ID;
		if( (get_user_meta($user_id,'member_status',true) == 'Active') or (get_user_meta($user_id,'member_status',true) == 'Qualified') ){
		$user_name = $user->user_login;
		//$user_login = $user->user_login;
		$type = get_user_meta($user_id, 'customer_type', true); 
		$option = array("option"=>$user_name,"value"=>$user_id);

		array_push($sponsor_list_1,$option);
		if(($type == 'P') OR ($type == 'B')){
			array_push($sponsor_list_2,$option);				
		}
		}

	endforeach;

	if(($customer_type == 'S') or ($customer_type == 'U')){
		echo json_encode($sponsor_list_2);
	}else{
		echo json_encode($sponsor_list_1);
	}

	wp_die(); 
}

/*Ajax function to list sponsors in admin user profile/edit page -starts*/
add_action( 'wp_ajax_profile_sponsor_list_action', 'profile_sponsor_list_action' );

function profile_sponsor_list_action() {
	$customer_type = $_POST['type'];
	$flag = $_POST['flag'];
	$user = $_POST['user'];
	global $wpdb;
	$sponsor_list_1 = array();
	$sponsor_list_2 = array();

	$check_sponsor = "empty";
	if($flag == "1"){

		$user_data = $wpdb->get_row("SELECT * FROM $wpdb->users WHERE `user_login` = '$user'");
		$ID = $user_data->ID;
		$sponsor_value = get_user_meta($ID, 'your_sponsor', true);
		$sponsor_option = $wpdb->get_row("SELECT * FROM $wpdb->users WHERE `ID` = '$sponsor_value'");
		$option_name = $sponsor_option->user_login;
		if(($customer_type == 'S') or ($customer_type == 'U')){
		array_push($sponsor_list_2,array("option"=>$option_name,"value"=>$sponsor_value));
		}else{
		array_push($sponsor_list_1,array("option"=>$option_name,"value"=>$sponsor_value));
		}
		$check_sponsor = $sponsor_value;
	}
	if( current_user_can('administrator') ) {  
	array_push($sponsor_list_1,array("option"=>"Select Your Sponsor","value"=>"0"));
	array_push($sponsor_list_2,array("option"=>"Select Your Sponsor","value"=>"0"));

	foreach ( $wpdb->get_results("SELECT ID, user_login, display_name FROM $wpdb->users ORDER BY user_login") as $user ) :
		$user_id = $user->ID;
		if( (get_user_meta($user_id,'member_status',true) == 'Active') or (get_user_meta($user_id,'member_status',true) == 'Qualified') ){
		$user_name = $user->user_login;
		$type = get_user_meta($user_id, 'customer_type', true); 
		$option = array("option"=>$user_name,"value"=>$user_id);
		array_push($sponsor_list_1,$option);
		if(($type == 'P') OR ($type == 'B')){
			array_push($sponsor_list_2,$option);				
		}
		}
	endforeach;
	}
		if(($customer_type == 'S') or ($customer_type == 'U')){
			echo json_encode($sponsor_list_2);
		}else{
			echo json_encode($sponsor_list_1);
		}
	wp_die(); 
}

/*Ajax function to change additional details in admin user profile/edit page -starts*/
add_action( 'wp_ajax_profile_extra_action', 'profile_extra_action' );
function profile_extra_action(){
	$customer_type = $_POST['type'];
	$user = $_POST['user'];
	global $wpdb;
	$user_details = $wpdb->get_row("SELECT * FROM $wpdb->users WHERE `user_login` = '$user'");
	$joindate = $user_details->user_registered;

	switch($customer_type){
			case "P": 
				$days =  get_option('custom_profile_op_exp_date_P');
				$expiry_date = date('Y-m-d',strtotime($joindate) + (24*3600*$days));
				$member_status = get_option('custom_profile_op_member_status_P');
				break;
			case "B": 
				$days =  get_option('custom_profile_op_exp_date_B');
				$expiry_date = date('Y-m-d',strtotime($joindate) + (24*3600*$days));
				$member_status = get_option('custom_profile_op_member_status_S');
				break;
			case "S": 
				$days =  get_option('custom_profile_op_exp_date_S');
				$expiry_date = date('Y-m-d',strtotime($joindate) + (24*3600*$days));
				$member_status = get_option('custom_profile_op_member_status_S');
				break;
			case "U": 
				$days =  get_option('custom_profile_op_exp_date_U');
				$expiry_date = date('Y-m-d',strtotime($joindate) + (24*3600*$days));
				$member_status = get_option('custom_profile_op_member_status_U');
				break;
			default:
				break;
	}
	$extra = array("date"=>$expiry_date,"status"=>$member_status);
	echo json_encode($extra);
	wp_die();
}


add_action( 'wp_ajax_genealogy_action', 'genealogy_action' );
function genealogy_action(){
	$selected_user = $_POST['user'];
	$genealogy_level = 3;
	//$genealogy_level = get_user_meta($selected_user,'genealogy_level',true);
	$members_list = [];
	array_push($members_list,$selected_user);
	global $wpdb;
	$query = "";		
	$query .= "SELECT ";
	for($i=0; $i< $genealogy_level; $i++){
		$j = $i+1;
		$query.= " um".$i.".user_id as LEVEL".$j.",um".$i.".meta_value AS SP".$j;
		if( $genealogy_level != ($i+1) ){
			$query.= ",";	
		}
	}
	$query.=" FROM wp_users u INNER JOIN wp_usermeta um0 ON (u.id = um0.meta_value AND um0.meta_key = 'your_sponsor' AND um0.meta_value = '$selected_user')";
	for($i=1; $i< ($genealogy_level+1); $i++){
		$j = $i-1;
		$query .= " LEFT JOIN wp_usermeta um".$i." ON (um".$i.".meta_value = um".$j.".user_id AND um".$i.".meta_key = 'your_sponsor')";
	}

	$return = [];

	foreach ( $wpdb->get_results("$query") as $row ):			
		$_data = [];
    		$heirarchy = [];
    		foreach ($row as $k=>$v){
        		$sp = str_replace('SP', '', $k);
        		if (is_numeric($sp)){
            			if (! isset($heirarchy[$sp])) $heirarchy[$sp] = [];
            			$heirarchy[$sp]['SP'] = $v; 
        		}
        		$level = str_replace('LEVEL', '', $k);
        		if (is_numeric($level)){
            			if (! isset($heirarchy[$level])) $heirarchy[$level] = [];
            			$heirarchy[$level]['LEVEL'] = $v;
				if(isset($v)) { array_push($members_list,$v); }
        		}
    		}
    		if (isset($heirarchy[1])) {
        		$_data[$heirarchy[1]['SP']] = get_heirarchy_data($heirarchy);
   		}
    		$return = array_replace_recursive($return, $_data);
	endforeach;

    if (empty($return)) { $return[$selected_user] = []; }
	$list = array_unique($members_list);
	$details = getDetailsOfUsers($list);		
	echo json_encode(array("levels"=>$return, "details"=>$details));
	wp_die();
}

add_action( 'wp_ajax_member_status_action', 'member_status_action' );
function member_status_action() {
	
	$level_percent = $_POST['level'];
	$status_level = $_POST['status_level'];
	$levels =  array();
	$i = 1;
	foreach($level_percent as $percent){		
		array_push($levels,array($i=>$percent));	
		$i++;
	}
	update_option('member_status_levels',$status_level);
	update_option('member_status_level_percentages',$levels);
	echo json_encode('true');
	wp_die();
}

add_action( 'wp_ajax_reward_table_action', 'reward_table_action' );
function reward_table_action() {	
	$level_percent = $_POST['level'];
	$status_level = $_POST['status_level'];
	$levels =  array();
	$i = 1;
	foreach($level_percent as $percent){		
		array_push($levels,array($i=>$percent));	
		$i++;
	}
	update_option('reward_levels',$status_level);
	update_option('reward_level_percentages',$levels);

	echo json_encode('true');
	wp_die();
}

function get_heirarchy_data($heirarchy = [], $index = 1)
{
    if (isset($heirarchy[$index + 1]) && $heirarchy[$index + 1]['SP'] != null)
    {
        if ($heirarchy[$index]['LEVEL'] == $heirarchy[$index + 1]['SP'])
        {
            return [$heirarchy[$index + 1]['SP'] => get_heirarchy_data($heirarchy, $index + 1) ];
        }
        return [];
    }
    return [$heirarchy[$index]['LEVEL']=>[]];
}

function getDetailsOfUsers($list){
	global $wpdb;
	$details = [];
	foreach($list as $value){
		$user_details = [];
		$id = $value;
		$user = get_user_by('ID',$id);
		$user_details = array("username"=>$user->user_login, "id"=>$user->ID, "type"=>get_user_meta($id,'customer_type',true), "level"=>get_user_meta($id,'membership_level',true), "status"=>get_user_meta($id,'member_status',true));
		array_push($details,$user_details);
	}
return $details;
}

