<?php
class mlm_plugin_backend
{
    public function __construct(){
        add_action('init', array($this, 'init_wc_sdp'));
        add_action( 'admin_menu', array($this, 'wpdocs_register_my_custom_menu_page'));
        // add_action('woocommerce_loaded', array($this, 'load_wcsdp'));
    }
    public function init_wc_sdp(){
    }
    public function wpdocs_register_my_custom_menu_page(){
    }
}
new mlm_plugin_backend();

function my_plugin_create_db() {
	global $wpdb;
	$charset_collate = $wpdb->get_charset_collate();
	$table_name = $wpdb->prefix . 'user_commission';
	$sql = "CREATE TABLE IF NOT EXISTS $table_name (
		uc_id bigint(20) NOT NULL AUTO_INCREMENT,
		uc_user_id bigint(20) NOT NULL,
		uc_date datetime DEFAULT '0000-00-00 00:00:00' NOT NULL,
		uc_membership_level varchar(255) NOT NULL,
		uc_total_commission varchar(255) NOT NULL,
		uc_status  varchar(10) DEFAULT 'true' NOT NULL,
		UNIQUE KEY uc_id (uc_id)
	) $charset_collate;";
	require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
	dbDelta( $sql );
}

/*Adding scripts and styles*/
add_action( 'init', 'add_custom_script' );
function add_custom_script(){      
	wp_register_script( 'custom-script', MLM_PLUGIN_ASSETS_URL.'js/backend/sponsor_list.js');
	wp_localize_script( 'custom-script', 'frontendajax', array( 'ajaxurl' => admin_url( 'admin-ajax.php' )));
	wp_enqueue_script( 'jquery' );
    wp_enqueue_script( 'custom-script' );
}

add_action('admin_enqueue_scripts', 'edit_profile_script');
function edit_profile_script() {
	global $pagenow; 		
	wp_enqueue_script( 'jquery' );
 	if (($pagenow == 'user-edit.php') or ($pagenow == 'profile.php')) {    
		wp_register_script( 'user-custom-ajax', 'https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.0/jquery.min.js' );  
		wp_enqueue_script( 'user-custom-ajax' );
		// wp_register_script( 'custom-profile-script', plugins_url('/custom_plugin/edit_profile_sponsor.js') );
		wp_enqueue_script( 'custom-profile-script',  MLM_PLUGIN_ASSETS_URL . 'js/backend/edit_user.js', array(), '1.0.0', true );		
		wp_localize_script( 'custom-profile-script', 'frontendajax', array( 'ajaxurl' => admin_url( 'admin-ajax.php' )));
    		wp_enqueue_script( 'custom-profile-script' );
    	}

		if (isset($_GET['page'])) {
	if (( $pagenow == 'options-general.	' ) and ($_GET['page'] == 'member-status')) { 
 		wp_register_script( 'member_status-script', MLM_PLUGIN_ASSETS_URL . 'js/backend/member_status.js' );
		 wp_localize_script( 'member_status-script', 'frontendajax', array( 'ajaxurl' => admin_url( 'admin-ajax.php' )));
    	wp_enqueue_script( 'member_status-script' );
		wp_enqueue_style( 'member-status-style', MLM_PLUGIN_ASSETS_URL .'css/backend/member_status.css' );
	}
}
	if (( $pagenow == 'admin.php' ) and ($_GET['page'] == 'genealogy.php')) {  
		// wp_enqueue_script( 'mlm-script',  MLM_PLUGIN_ASSETS_URL . 'js/frontend/script.js', array(), '1.0.0', true );	
		wp_register_script('date-script1','//code.jquery.com/jquery-1.11.3.min.js');
		wp_enqueue_script('date-script1');	
		wp_register_script('date-script2','//ajax.googleapis.com/ajax/libs/jqueryui/1.11.3/jquery-ui.min.js');
		wp_enqueue_script('date-script2');
		wp_register_script('date-script-3',plugins_url('/mlm-plugin/month-year-picker/jquery.mtz.monthpicker.js'));
		wp_enqueue_script('date-script-3');
		wp_enqueue_style('date-style','//ajax.googleapis.com/ajax/libs/jqueryui/1.11.3/themes/smoothness/jquery-ui.css"');
		wp_register_script( 'main-script', '//cdnjs.cloudflare.com/ajax/libs/chosen/1.4.2/chosen.jquery.min.js' );  
		wp_enqueue_script( 'main-script' );
		// wp_register_script( 'admin-genealogy-script', plugins_url('/custom_plugin/admin_genealogy.js') );
		wp_enqueue_script( 'admin-genealogy-script',  MLM_PLUGIN_ASSETS_URL . 'js/backend/admin_genealogy.js', array(), '1.0.0', true );		wp_localize_script( 'admin-genealogy-script', 'frontendajax', array( 'ajaxurl' => admin_url( 'admin-ajax.php' )));
		wp_enqueue_script( 'admin-genealogy-script' );
		wp_enqueue_style( 'chosen-style', '//cdnjs.cloudflare.com/ajax/libs/chosen/1.4.2/chosen.min.css' );
		wp_enqueue_style( 'genealogy-style',  MLM_PLUGIN_ASSETS_URL . 'css/backend/genealogy.css') ;		
	}

	if (( $pagenow == 'admin.php' ) and ($_GET['page'] == 'commission_report.php')) {	
		wp_enqueue_script( 'main-script', '//cdnjs.cloudflare.com/ajax/libs/chosen/1.4.2/chosen.jquery.min.js' );
		wp_enqueue_style( 'chosen-style', '//cdnjs.cloudflare.com/ajax/libs/chosen/1.4.2/chosen.min.css' );
		wp_enqueue_script('commission-script', MLM_PLUGIN_ASSETS_URL . 'js/backend/commission.js');
		wp_enqueue_script('date_script1','//cdn.jsdelivr.net/momentjs/latest/moment.min.js');
		wp_enqueue_style('date_style1','//cdn.jsdelivr.net/bootstrap/3/css/bootstrap.css');
		wp_enqueue_script('date_script2','//cdn.jsdelivr.net/bootstrap.daterangepicker/2/daterangepicker.js');
		wp_enqueue_style('date_script2','//cdn.jsdelivr.net/bootstrap.daterangepicker/2/daterangepicker.css');
		wp_enqueue_style( 'member-status-style', MLM_PLUGIN_ASSETS_URL . 'css/backend/member_status.css') ;
	}
}

add_action('admin_menu','genealogy_menu');
function genealogy_menu(){
	add_menu_page( 'Genealogy', 'Genealogy', 'read', 'genealogy.php', 'genealogy_page', 'dashicons-id-alt', '2'  );
}
///name="download_genealogy" 19-9-23
function genealogy_page(){
	if( current_user_can('administrator') ) {  
		/*Admin Genealogy*/
		global $wpdb;
		echo'<div class="wrap">
		<h2>Genealogy</h2>';
		echo'</div>';
		$users = get_users();
		$genealogy_level = 3;
    	$current_user = wp_get_current_user();
		$selected_user = $current_user->ID;	
		echo'<button id="download" class="btn btn-primary">Download</button>
		<div id="download-div" style="width:400px; height:70px; display:none;  background:#FCFCFC; border-radius:3px;">
		<p><button style="float:right; background:#FCFCFC; border:none;" onclick="display_picker()" >&times;</button></p>
		<p style="padding: 10px 10px 0px 10px;"><label>Select the month and year:</label><input id="picker" type="text"></p>
		<p style="padding-left:10px; display:none;" class="blink"><a name="down" href="'.admin_url(). '">Download</a></p>
		</div>';
		echo'<div class="clt-head">
			<div class="clt-row">
			<div class="clt-col1">';
				echo'<select class="my_select_box" data-placeholder="Select Your Options" name="customer">';
					echo'<option value="0">Search a Customer</option>';
					foreach ($users as $user):				
						$user_login = $user->user_login; 
						$user_id = $user->ID; 
					echo'<option value="'.$user_id.'">'.$user_login.'</option>';
					endforeach;
        			echo'</select>';
			echo'</div>';
			for($i=1; $i<=$genealogy_level; $i++){
			echo'<div class="clt-col" >Level '.$i.'</div>';
			}
			echo'</div>
		</div>';
		echo'<input type="hidden" id="ad_gen_trigger" value="'.$selected_user.'"/>';
		echo' <div class="clt">';
        		echo'<ul class="start">
			</ul>
		      </div>';
	}else{
		/*Distributer Genealogy*/
		global $wpdb;	

		echo'<div class="wrap">
		<h2>Genealogy</h2>';
		echo'</div>';

		echo'<button id="download" class="btn btn-primary">Download</button>
		<div id="download-div" style="width:400px; height:70px; display:none;  background:#FCFCFC; border-radius:3px;">
		<p><button style="float:right; background:#FCFCFC; border:none;" onclick="display_picker()" >&times;</button></p>
		<p style="padding: 10px 10px 0px 10px;"><label>Select the month and year:</label><input id="picker" type="text"></p>
		<p style="padding-left:10px; display:none;" class="blink"><a name="down" href="'.admin_url(). '">Download</a></p>
		</div>';
		$genealogy_level = 3;
    	$current_user = wp_get_current_user();
		$selected_user = $current_user->ID; 
		
		echo'<input type="hidden" id="gen_trigger" value="'.$selected_user.'"/>';

		echo'<div class="clt-head">
			<div class="clt-row">
			<div class="clt-col">';
		echo"Distributer";
		echo'</div>';

			for($i=1; $i<=$genealogy_level; $i++){
				echo'<div class="clt-col" >Level '.$i.'</div>';
			}
			echo'</div>
		</div>';

		echo'<div class="clt">';
        echo'<ul class="start"></ul></div>';
	}
	// status_update_cron_exec();
}

add_action('admin_menu','commission_menu');
function commission_menu(){
	add_menu_page( 'Commission_calculation', 'Commision Reports', 'read', 'commission_report.php', 'commission_calculation_page', 'dashicons-media-spreadsheet', '3'  );
}

function commission_calculation_page(){
	/*Admin Commission*/
	// commission_update_cron_exec();
	global $wpdb;
	echo '<div id="loader_div" class="loader_div"></div>';
	echo'<div class="wrap">
	<h2>Commission Report</h2>';
	echo'</div>';
	$users = get_users();
	echo'<table class="form-table">
	<tr>
	<form method="GET" action="'.admin_url(). '?downloadR=commissionreport" >
		<th><label for="customer">Customer Name</label></th>
		<td>';
		if( current_user_can('administrator') ) {  
		echo'<select class="my_select_box" name="customer" id="customer" data-placeholder="Select Your Options" >
			<option value="0" >Search a Customer</option>';
				foreach ($users as $user):
					$user_login = $user->user_login;
					$user_id = $user->ID;
					if(get_user_meta($user_id,'member_status','true') == "Active" || get_user_meta($user_id,'member_status','true') == "Inactive" || get_user_meta($user_id,'member_status','true') == "Terminated" ){
					echo'<option value="'.$user_id.'">'.$user_login.'</option>';
					}
				endforeach;
			echo'</select>';
		}else{
		echo'<input type="text"  value='.wp_get_current_user()->user_login.' readonly  />';
		echo'<input type="hidden"  id="customer" value='.wp_get_current_user()->ID.' />';
		}
		echo'</td>
	</tr>
	<tr>
		<th><label for="date_range">Date Range</label></th>
		<td>
		
			<input type="text" name="daterange"  />
			<input type="hidden" id="from"/>
			<input type="hidden" id="to"/>
		</td>
	</tr>
	<tr>
	<td><select name="print" id="print"  >
	<option value="Excel">Excel spread sheet</option>
	<option value="CSV">CSV</option>
	<option value="PDF">PDF</option>
	<option value="picture">Picture</option>
  </select></td>
<td>
	<input type="submit" class="button button-primary" name="downloadR" value="Download" id="downloadButton" disabled >
	</form>
	</tr></table>'; 
}
// value="01/01/2017 - 01/31/2017"   disabled
add_action('wp_loaded','commission_report_download');
function commission_report_download(){
	global $wpdb;
    if ( isset( $_GET['downloadR'] ) ) {		
		$customer = $_GET['customer'];
		$daterange = $_GET['daterange'];
		$daterange_both=explode(' - ', $daterange);
		$from = $daterange_both[0];
		$from = $from.' 00:00:00';
		$to = $daterange_both[1];
		$to = $to.' 23:59:59';	
		$printCommissionReport=$_GET['print'];
		$level1_count = get_level_1_users_count_report($customer,$from,$to);	
		// print_r($level1_count);
		// die;
        $membership_level = explode(',',get_membership_level($level1_count));
		$ml_value = $membership_level[0];  
		$ml_key = $membership_level[1]; 		
		update_user_meta($customer,'membership_level',$ml_value);
	        if($printCommissionReport === 'Excel'){
				create_commission_xlsx_file_report($customer , $from , $to , "download");
				}
			elseif($printCommissionReport === 'CSV'){
				create_commission_csv_file_report($customer , $from , $to , "download");
				}
			elseif($printCommissionReport === 'PDF'){
				create_commission_pdf_file_report($customer , $from , $to , "download");
				}
			elseif($printCommissionReport === 'picture'){
                create_commission_picture_report($customer , $from , $to , "download");
    			}
			else{
				echo "Invalid or no format selected.";
				exit;
				}
  }	
}


	require_once  MLM_PLUGIN_PATH.'vendor/autoload.php';
	use PhpOffice\PhpSpreadsheet\Style\Border;
	use PhpOffice\PhpSpreadsheet\Style\Alignment;
	use PhpOffice\PhpSpreadsheet\Style\Font;
	use PhpOffice\PhpSpreadsheet\Spreadsheet;
	use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
	use PhpOffice\PhpSpreadsheet\Style\Color;
	use PhpOffice\PhpSpreadsheet\IOFactory;
	use PhpOffice\PhpSpreadsheet\Writer\IWrite;
	use PhpOffice\PhpSpreadsheet\RichText\RichText;
 function create_commission_xlsx_file_report($customer,$from,$to,$data){
	$customer_name = get_userdata($customer)->user_login;
	$customer_email = get_userdata($customer)->user_email;
	$member_status = get_user_meta($customer,'member_status',true);
	$objPHPExcel = new Spreadsheet();
	$sheet1  = $objPHPExcel->getActiveSheet();
    $sheet1->setTitle('Commission Report');
    $sheet1->setCellValue('A1', 'Hello World !');
    $alignment = new Alignment();
	$richText = new RichText();
    $objPHPExcel->getActiveSheet()->getDefaultRowDimension()->setRowHeight(20);
    $objPHPExcel->getActiveSheet()->getDefaultColumnDimension()->setWidth(25);
    $cellRange = 'A1:G1';
    $objPHPExcel->getActiveSheet()->getStyle($cellRange)->getFont()->setSize(18)->setColor(new Color(Color::COLOR_BLUE));
    $objPHPExcel->getActiveSheet()->getRowDimension(5)->setRowHeight(25);
    $objPHPExcel->getActiveSheet()->mergeCells('A1:G1');
    $alignment->setHorizontal(Alignment::HORIZONTAL_CENTER);
    $objPHPExcel->getActiveSheet()->getStyle('A1:G1')->getAlignment()->setHorizontal($alignment->getHorizontal());
    $objPHPExcel->getActiveSheet()->setCellValue('A1', 'COMMISSION REPORT');
    $alignment->setHorizontal(Alignment::HORIZONTAL_LEFT);
	$objPHPExcel->getActiveSheet()->getStyle('A2:F4')->getAlignment()->setHorizontal($alignment->getHorizontal());
	$objPHPExcel->getActiveSheet()->getStyle('A2:F4')->getFont()->setSize(12)->setBold(true);	
	$objPHPExcel->getActiveSheet()->setCellValue('A2','Member User Name :');
	if($member_status == 'Inactive'){
	$richText->createTextRun($customer_name);
	$statusRun = $richText->createTextRun(' (' . $member_status . ')');
	$statusRun->getFont()->setColor(new Color(Color::COLOR_RED));
	$objPHPExcel->getActiveSheet()->setCellValue('B2', $richText);
	}
	else{
		$objPHPExcel->getActiveSheet()->setCellValue('B2',$customer_name);
	}
	$objPHPExcel->getActiveSheet()->setCellValue('D2','Date and Time :');
	$objPHPExcel->getActiveSheet()->setCellValue('E2',date('Y-m-d H:i'));
	$level1_count = get_level_1_users_count_report($customer,$from,$to); 
	$membership_level = explode(',',get_membership_level($level1_count));
	$ml_value = $membership_level[0];
	$ml_key = $membership_level[1];
	$objPHPExcel->getActiveSheet()->setCellValue('A3','Membership Level :');
	$objPHPExcel->getActiveSheet()->setCellValue('B3',$ml_value);
	$objPHPExcel->getActiveSheet()->setCellValue('C3','Start date :');
	$objPHPExcel->getActiveSheet()->setCellValue('D3',$from);
	$objPHPExcel->getActiveSheet()->setCellValue('E3','End date :');
	$objPHPExcel->getActiveSheet()->setCellValue('F3',$to);

	if($member_status == 'Terminated'){
	$statusRun = $richText->createTextRun($member_status);
    $objPHPExcel->getActiveSheet()->mergeCells('A4:G5');
    $objPHPExcel->getActiveSheet()->setCellValue('A4', $richText);
    $objPHPExcel->getActiveSheet()->getStyle('A4:G5')
    ->getFont()
    ->setSize(18)
    ->setColor(new Color(Color::COLOR_RED));
	$objPHPExcel->getActiveSheet()->getRowDimension(5)->setRowHeight(25);
    $alignment = $objPHPExcel->getActiveSheet()->getStyle('A4:G5')->getAlignment();
    $alignment->setHorizontal(Alignment::HORIZONTAL_CENTER);
    $alignment->setVertical(Alignment::VERTICAL_CENTER);
	}
else{
	$objPHPExcel->getActiveSheet()->mergeCells('A4:B4');
	$objPHPExcel->getActiveSheet()->setCellValue('A4','Downline Customer information');
	$alignment->setHorizontal(Alignment::HORIZONTAL_LEFT);
	$objPHPExcel->getActiveSheet()->getStyle('A5:I5')->getAlignment()->setHorizontal($alignment->getHorizontal());
	$objPHPExcel->getActiveSheet()->getStyle('A5:I5')->getFont()->setSize(12)->setBold(true);	
	$objPHPExcel->getActiveSheet()->setCellValue('A5','User Name');
	$objPHPExcel->getActiveSheet()->setCellValue('B5','Customer Type');
	$objPHPExcel->getActiveSheet()->setCellValue('C5','Level below you');
	$objPHPExcel->getActiveSheet()->setCellValue('D5','Spend this month');
	$objPHPExcel->getActiveSheet()->setCellValue('E5','Remove VAT 15%');
	$objPHPExcel->getActiveSheet()->setCellValue('F5','Total excluding VAT');
	$objPHPExcel->getActiveSheet()->setCellValue('G5','Total Profit');
	$objPHPExcel->getActiveSheet()->setCellValue('H5','Percentage');
	$objPHPExcel->getActiveSheet()->setCellValue('I5','Rand Value');
	$objPHPExcel->getActiveSheet()->freezePane("A6");
	$all_level_users = get_all_level_users_start($customer);
	$total_commission = 0;
	$y=7;
	$alignment->setHorizontal(Alignment::HORIZONTAL_LEFT);
	$objPHPExcel->getActiveSheet()->getStyle('A'.$y.':I'.($y+count($all_level_users)))->getAlignment()->setHorizontal($alignment->getHorizontal());
	$objPHPExcel->getActiveSheet()->getStyle('A'.$y.':I'.($y+count($all_level_users)))->getFont()->setSize(12);	
	foreach($all_level_users as $users){
	$objPHPExcel->getActiveSheet()->setCellValue('A'.$y,get_userdata($users)->user_login);
	$objPHPExcel->getActiveSheet()->setCellValue('B'.$y,get_user_meta($users,'customer_type','true'));
	$objPHPExcel->getActiveSheet()->setCellValue('C'.$y,get_level($users,$customer,0,0));
	$objPHPExcel->getActiveSheet()->setCellValue('D'.$y,'R'.get_amount_spent($users,$from,$to));
		$level_percent = get_option("member_status_level_percentages");
		$level = get_level($users,$customer,0,0);
		$amount_spent = get_amount_spent($users,$from,$to);	
		$percentage = $level_percent[$level-1][$level][$ml_key];		
		// $commission = round(($amount_spent*($percentage/100)),2);
		$exclude_vat = round($amount_spent/115*15, 2);
		$total_without_vat=$amount_spent-$exclude_vat;
        $markup=round($total_without_vat/140*40,2);
		$commission = round(($markup*($percentage/100)),2);
		$total_commission += $commission;
	$objPHPExcel->getActiveSheet()->setCellValue('E'.$y,$exclude_vat);
	$objPHPExcel->getActiveSheet()->setCellValue('F'.$y,$total_without_vat);
	$objPHPExcel->getActiveSheet()->setCellValue('G'.$y,$markup);
	$objPHPExcel->getActiveSheet()->setCellValue('H'.$y,$percentage.' %');
	$objPHPExcel->getActiveSheet()->setCellValue('I'.$y,'R '.$commission);
	$y++;	
	}
	$y = $y+2;
	$alignment->setHorizontal(Alignment::HORIZONTAL_LEFT);
	$objPHPExcel->getActiveSheet()->getStyle('A'.$y.':F'.($y+3))->getAlignment()->setHorizontal($alignment->getHorizontal());
	$objPHPExcel->getActiveSheet()->getStyle('A'.$y.':F'.($y+3))->getFont()->setSize(12)->setBold(true);	
	$objPHPExcel->getActiveSheet()->mergeCells('A'.$y.':B'.$y);
	$objPHPExcel->getActiveSheet()->setCellValue('A'.$y,'Total Commission for selected period :');
	$objPHPExcel->getActiveSheet()->setCellValue('F'.$y,'R '.$total_commission);

	$objPHPExcel->getActiveSheet()->mergeCells('A'.($y+1).':B'.($y+1));
	$objPHPExcel->getActiveSheet()->setCellValue('A'.($y+1),'Commission paid to you last month :');
	$objPHPExcel->getActiveSheet()->setCellValue('F'.($y+1),'R ');
}
	if($data == "download"){
	// Redirect output to a client’s web browser (xlsx)
	$filename=$customer_name.'--commission_report.xlsx';
	ob_end_clean();
	header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
	// header('Content-Disposition: attachment;filename="commission report.xlsx"');
	header('Content-Disposition: attachment; filename="' . $filename . '.xlsx"');

	header('Cache-Control: max-age=0');
	// If you're serving to IE 9, then the following may be needed
	header('Cache-Control: max-age=1');
	// If you're serving to IE over SSL, then the following may be needed
	header ('Expires: Mon, 26 Jul 1997 05:00:00 GMT'); // Date in the past
	header ('Last-Modified: '.gmdate('D, d M Y H:i:s').' GMT'); // always modified
	header ('Cache-Control: cache, must-revalidate'); // HTTP/1.1
	header ('Pragma: public'); // HTTP/1.0
	$writer = new Xlsx($objPHPExcel);
	$writer->save('php://output');
		exit;
	}else{	
// Rewards Table Code Start
	$customer_type = get_user_meta($customer,'customer_type','true');
	if( $customer_type != 'B'){
      $sheet2 = $objPHPExcel->createSheet();
      $sheet2->setTitle('Rewards');
	$y= 1;
	$sheet2->getDefaultRowDimension()->setRowHeight(20);
	$sheet2->getDefaultColumnDimension()->setWidth(25);
	$font = $sheet2->getStyle('A' . $y . ':G' . $y)->getFont();
    $font->setSize(18);
    $font->setColor(new Color(Color::COLOR_BLUE));
    $font->setBold(true);
	$sheet2->getRowDimension($y)->setRowHeight(25); // Use $y directly as it's the row number
	$sheet2->mergeCells('A' . $y . ':G' . $y);
	$alignment->setHorizontal(Alignment::HORIZONTAL_CENTER);
	$objPHPExcel->getActiveSheet()->getStyle('A'.($y).':G'.($y))->getAlignment()->setHorizontal($alignment->getHorizontal());
	$sheet2->mergeCells('A'.($y).':G'.($y));
    $sheet2->setCellValue('A'.($y), 'Rewards You have Received');
	$sheet2->getStyle('A3:F3')->getFont()->setSize(12)->setBold(true);	
	$fontHeader = new Font();
    $fontHeader->setSize(12)->setBold(true);
	$sheet2->setCellValue('A'.($y+2),'Customer Status');
	$sheet2->getStyle('A' . ($y + 2))->setFont($fontHeader);
	$member_status = get_option("reward_levels");
	$column = 'B'; 	
	foreach ($member_status as $k => $val) {
		$sheet2->setCellValue($column . ($y + 2), $k);
		$sheet2->getStyle($column . ($y + 2))->setFont($fontHeader);
		$column++;
	}
	$sheet2->setCellValue('A' . ($y + 4), 'Reward #');
    $total_collect_reward=reward_table($customer ,$from,$to);
	$total_reward = $total_collect_reward[0];
	$reward_level = $total_collect_reward[1];
	for($i=1; $i<=5; $i++){
		$sheet2->setCellValue('A' .($y+5), $i);
	$y++;
	}
	if ($ml_value == 'BRONZE') {
        $greenFontStyle = [
			'font' => [
			'color' => ['rgb' => Color::COLOR_GREEN],
			],
         ];
        $sheet2->getStyle("B".($y-1+(int)$reward_level)."")->applyFromArray($greenFontStyle);
		$sheet2->setCellValue('B'.($y-1+(int)$reward_level), $total_reward);
    } 
	elseif ($ml_value == 'SILVER') {
		$greenFontStyle = [
			'font' => [
			'color' => ['rgb' => Color::COLOR_GREEN],
			],
         ];
        $sheet2->getStyle("C".($y-1+(int)$reward_level)."")->applyFromArray($greenFontStyle);	
        $sheet2->setCellValue('C'.($y-1+(int)$reward_level), $total_reward);
	
    } elseif ($ml_value == 'GOLD') {
		$greenFontStyle = [
			'font' => [
			'color' => ['rgb' => Color::COLOR_GREEN],
			],
         ];
        $sheet2->getStyle("D".($y-1+(int)$reward_level)."")->applyFromArray($greenFontStyle);	
        $sheet2->setCellValue('D'.($y-1+(int)$reward_level), $total_reward);
	} elseif ($ml_value == 'PLATINUM') {
		$greenFontStyle = [
			'font' => [
			'color' => ['rgb' => Color::COLOR_GREEN],
			],
         ];
        $sheet2->getStyle("E".($y-1+(int)$reward_level)."")->applyFromArray($greenFontStyle);	
		$sheet2->setCellValue('E'.($y-1+(int)$reward_level), $total_reward);
	} elseif ($ml_value == 'DIAMOND') {
		$greenFontStyle = [
			'font' => [
			'color' => ['rgb' => Color::COLOR_GREEN],
			],
         ];
        $sheet2->getStyle("F".($y-1+(int)$reward_level)."")->applyFromArray($greenFontStyle);	
        $sheet2->setCellValue('F'.($y-1+(int)$reward_level), $total_reward);
	}
	}
	// Rewards Table Code End
		$writer = IOFactory::createWriter($objPHPExcel, 'Xlsx');	
		$file_path = MLM_PLUGIN_PATH . 'excelFolder/example.xlsx';
		$writer->save($file_path);
		$attachments = array($file_path);	
			$to = $customer_email;                // Send the email with the XLSX file as an attachment
			$subject = 'Excel File Attachment';
			$message = 'Please find the attached XLSX file.';
			$headers = array(
				'Content-Type: text/html; charset=UTF-8',
			);		
			try{
			// wp_mail("aditi.a.expinator@gmail.com", $subject, $message, $headers, $attachments);
			wp_mail($customer_email, $subject, $message, $headers, $attachments);
			echo "done";
			}catch(Exception $e) {
			echo 'Message: ' .$e->getMessage();
			}	
		}	
}

function create_commission_csv_file_report($customer,$from,$to,$data){
	$customer_name = get_userdata($customer)->user_login;
	$customer_email = get_userdata($customer)->user_email;
	$member_status = get_user_meta($customer,'member_status',true);
	$filename=$customer_name.'--commission_report';
ob_start();                                                 // Start the output buffer.
header('Content-Type: text/csv; charset=utf-8');         	// Set PHP headers for CSV output.
// header('Content-Disposition: attachment; filename=csv_export.csv');
header('Content-Disposition: attachment; filename=' . $filename . '.csv');
$level1_count = get_level_1_users_count_report($customer,$from,$to); 
$membership_level = explode(',',get_membership_level($level1_count));
$ml_value = $membership_level[0];
$ml_key = $membership_level[1];

// $commissionReport = [];
if ($member_status == 'Terminated') {
    $commissionReport = [
        ['', '', 'COMMISSION REPORT'],
        ['Member User Name :', $customer_name, '', 'Date and Time :', date('Y-m-d H:i')],
        ['Membership Level :', $ml_value, 'Start date :', $from, 'End date :', $from],
		['','','Terminated']
    ];
} else{
$commissionReport = array(
	['', '', 'COMMISSION REPORT'],
    ['Member User Name :', $customer_name, '', 'Date and Time :', date('Y-m-d H:i')],
    ['Membership Level :', $ml_value, 'Start date :', $from, 'End date :', $from],
    ['', '', 'Downline Customer information'],
    ['User Name', 'Customer Type', 'Level below you', 'Spend this month', 'Remove VAT 15%', 'Total excluding VAT', 'Total Profit', 'Percentage', 'Rand Value']
);
}
$nextLine=array(
	['', '', '', '', '', '', '', '', '']
);
$all_level_users = get_all_level_users_start($customer);
$customer_information=array();
	foreach($all_level_users as $users){	
		$getUsers=get_userdata($users)->user_login;
		$getType=get_user_meta($users,'customer_type','true');
		$getLevel=get_level($users,$customer,0,0);
		$getAmount='R'.get_amount_spent($users,$from,$to);	
	$level_percent = get_option("member_status_level_percentages");
	$level = get_level($users,$customer,0,0);
	$amount_spent = get_amount_spent($users,$from,$to);		
	$percentage = $level_percent[$level-1][$level][$ml_key];		
	// $commission = round(($amount_spent*($percentage/100)),2);
	$exclude_vat = round($amount_spent/115*15, 2);
	$total_without_vat=$amount_spent-$exclude_vat;
	$markup=round($total_without_vat/140*40,2);
	$commission = round(($markup*($percentage/100)),2);
	$total_commission += $commission;
	$customer_information[] = [$getUsers, $getType, $getLevel, $getAmount, $exclude_vat, $total_without_vat, $markup,
	 $percentage.' %', 'R '.$commission];
	};
	$nextLine1=array(
	['', '', '', '', '', '', '', '', '']
    );
    $total_commission_selected_period=array(
	['Total Commission for selected period :', '', '', '', '', 'R'.$total_commission]
    );
    $commission_paid_last_month=array(
	['Commission paid to you last month :', '', '', '', '','R ']
    );
    ob_end_clean();                               // Clean up output buffer before writing anything to CSV file.
    $fp = fopen('php://output', 'w' );            // Create a file pointer with PHP and Open a file in write mode ('w').
    foreach ($commissionReport as $fields) {         // Loop through the prepared data to output it to CSV file.
    fputcsv($fp, $fields);
    }

    foreach($nextLine as $break){
	fputcsv($fp, $break);
    }
    foreach ($customer_information as $userData) {
    fputcsv($fp, $userData);
    }
    foreach($nextLine1 as $break1){
	fputcsv($fp, $break1);
    }
    foreach($total_commission_selected_period as $total){
	fputcsv($fp, $total);
    }
    foreach($commission_paid_last_month as $paidCommission){
	fputcsv($fp, $paidCommission);
    }
    fclose($fp);              // Close the file pointer with PHP with the updated output.
      exit;
    }


function create_commission_pdf_file_report($customer,$from,$to,$data){
	$user = get_userdata($customer);
	$customer_name = get_userdata($customer)->user_login;
	$customer_email = get_userdata($customer)->user_email;
	$member_status = get_user_meta($customer,'member_status',true);

	require_once  MLM_PLUGIN_PATH.'vendor/autoload.php';
	$pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);
	$pdf->SetCreator(PDF_CREATOR);
	$pdf->SetAuthor('Your Name');
	$pdf->SetTitle('Sample PDF');
	$pdf->SetSubject('Generating PDF in PHP');
	$pdf->SetKeywords('PDF, TCPDF, PHP, example');
	$pdf->AddPage('L', 'A2');
	$level1_count = get_level_1_users_count_report($customer,$from,$to);
	$membership_level = explode(',',get_membership_level($level1_count));
	$ml_value = $membership_level[0];
	$ml_key = $membership_level[1];

	
    $pdf->Cell(0, 0, 'COMMISSION REPORT', 1, 1, 'C');
	$pdf->Ln();
	$pdf->SetFont("helvetica", "B", 12);
	$pdf->Cell(40, 0, "Member User Name :");
	if($member_status == 'Inactive'){
		
		$customerNameWidth = $pdf->GetStringWidth($customer_name);
		 // Calculate the position for $customer_name
		 $customerNameX = 60; // Adjust this value as needed
		 $customerNameY = $pdf->GetY();
		 
    // Calculate the position for $member_status
    $statusX = $customerNameX + $customerNameWidth + 5; // Adjust the gap as needed
    $statusY = $pdf->GetY();

    // Render $customer_name and $member_status
    $pdf->SetXY($customerNameX, $customerNameY);
    $pdf->Cell(0, 0, $customer_name);
	$pdf->SetTextColor(255, 0, 0);
    $pdf->SetXY($statusX, $statusY);
    $pdf->Cell(40, 0, ' (' . $member_status . ')');

    // Reset text color to black
    $pdf->SetTextColor(0, 0, 0);
	}
	else{

    $pdf->SetFont("helvetica", "", 12);
	$pdf->Cell(40, 0, $customer_name);
	}
	$pdf->SetFont("helvetica", "B", 12);
	$pdf->Cell(40, 0, "Date and Time :");
	$pdf->SetFont("helvetica", "", 12);
	$pdf->Cell(40, 0, date('Y-m-d H:i'));
	$pdf->Ln();
	$pdf->SetFont("helvetica", "B", 12);
	$pdf->Cell(40, 0, "Membership Level :");
	$pdf->SetFont("helvetica", "", 12);
	$pdf->Cell(40, 0, $ml_value);
    $pdf->SetFont("helvetica", "B", 12);
	$pdf->Cell(40, 0, "Start date :");
	$pdf->SetFont("helvetica", "", 12);
	$pdf->Cell(40, 0, $from);
	$pdf->SetFont("helvetica", "B", 12);
	$pdf->Cell(40, 0, "End date :");
	$pdf->SetFont("helvetica", "", 12);
	$pdf->Cell(40, 0, $to);
	$pdf->Ln();
	
	if($member_status == 'Terminated'){
	$pdf->SetTextColor(255,0,0);
	$pdf->SetFont('helvetica', '', 16);
	$cellWidth = 100;
    $cellHeight = 10;
    $leftMargin = 20;
    // Calculate the position to center the text within the cell
    $textWidth = $pdf->GetStringWidth("Terminated");
    $textX = $leftMargin + ($cellWidth - $textWidth) / 2;
    $textY = $pdf->GetY(); // Get the current Y position
    // Render the "Terminated" text in red and centered within the cell
    $pdf->SetXY($textX, $textY);
    $pdf->Cell($cellWidth, $cellHeight, "Terminated");
	$pdf->Ln();
	$pdf->SetTextColor(0, 0, 0);
	}
	else{
	$pdf->SetTextColor(0, 0, 0);
	$pdf->Ln();
	$pdf->SetFont('helvetica', '', 16);
	$pdf->Cell(100, 10, "Downline Customer information");
    $pdf->Ln();
	$pdf->SetFont("helvetica", "B", 12);
	$pdf->Cell(40, 0, "User Name");
	$pdf->SetFont("helvetica", "B", 12);
	$pdf->Cell(40, 0, "Customer Type");
	$pdf->SetFont("helvetica", "B", 12);
	$pdf->Cell(40, 0, "Level below you");
	$pdf->SetFont("helvetica", "B", 12);
	$pdf->Cell(50, 0, "Spend this month");
	$pdf->SetFont("helvetica", "B", 12);
	$pdf->Cell(50, 0, "Remove VAT 15%");
	$pdf->SetFont("helvetica", "B", 12);
	$pdf->Cell(50, 0, "Total excluding VAT");
	$pdf->SetFont("helvetica", "B", 12);
	$pdf->Cell(40, 0, "Total Profit");
	$pdf->SetFont("helvetica", "B", 12);
	$pdf->Cell(40, 0, "Percentage");
	$pdf->SetFont("helvetica", "B", 12);
	$pdf->Cell(40, 0, "Rand Value");
    $pdf->Ln();
	}

    $all_level_users = get_all_level_users_start($customer);
	$total_commission = 0;
	if(!empty($all_level_users)){
    foreach($all_level_users as $users){		
	$pdf->SetFont("helvetica", "", 12);
	$pdf->Cell(40, 10, get_userdata($users)->user_login);
	$pdf->SetFont("helvetica", "", 12);
	$pdf->Cell(40, 10, get_user_meta($users,'customer_type','true'));
	$pdf->SetFont("helvetica", "", 12);
	$pdf->Cell(40, 10, get_level($users,$customer,0,0));
	$pdf->SetFont("helvetica", "", 12);
	$pdf->Cell(50, 10, 'R'.get_amount_spent($users,$from,$to));
        $level_percent = get_option("member_status_level_percentages");
		$level = get_level($users,$customer,0,0);
		$amount_spent = get_amount_spent($users,$from,$to);		
		$percentage = $level_percent[$level-1][$level][$ml_key];		
		// $commission = round(($amount_spent*($percentage/100)),2);
		$exclude_vat = round($amount_spent/115*15, 2);
		$total_without_vat=$amount_spent-$exclude_vat;
        $markup=round($total_without_vat/140*40,2);
		$commission = round(($markup*($percentage/100)),2);
		$total_commission += $commission;
	$pdf->SetFont("helvetica", "", 12);
	$pdf->Cell(50, 10, $exclude_vat);
	$pdf->SetFont("helvetica", "", 12);
	$pdf->Cell(50, 10, $total_without_vat);
	$pdf->SetFont("helvetica", "", 12);
	$pdf->Cell(40, 10, $markup);
	$pdf->SetFont("helvetica", "", 12);
	$pdf->Cell(40, 10, $percentage.' %');
	$pdf->SetFont("helvetica", "", 12);
	$pdf->Cell(40, 10, 'R'.$commission);
	$pdf->Ln();
		}
	}
	else{
		$pdf->SetFont("helvetica", "", 12);
	    $pdf->Cell(40, 10, 'NO DATA FOUND');
	}

    $pdf->Ln();
	$pdf->SetFont("helvetica", "B", 12);
	$pdf->Cell(40, 10, "Total Commission for selected period :");
	$pdf->Cell(40, 10, "");
	$pdf->SetFont("helvetica", "", 12);
	$pdf->Cell(40, 10, 'R '.$total_commission);
	$pdf->Ln();
	$pdf->SetFont("helvetica", "B", 12);
	$pdf->Cell(40, 10,"Commission paid to you last month :");
	$pdf->Cell(40, 10, "");
	$pdf->SetFont("helvetica", "", 12);
	$pdf->Cell(40, 10, 'R ');
	$pdf->Output($customer_name.'--commission_report.pdf', 'D');
    }

	function create_commission_picture_report($customer,$from,$to,$data){
		$customer_name = get_userdata($customer)->user_login;
		$customer_email = get_userdata($customer)->user_email;
		$member_status = get_user_meta($customer,'member_status',true);
// Create an empty image canvas
$img = imagecreatetruecolor(1800, 1500);

// Set a background color
$bgColor = imagecolorallocate($img, 255, 255, 255);
imagefill($img, 0, 0, $bgColor);

$fontSize = 5;
    $string='COMMISSION REPORT';
	$textbgcolor = imagecolorallocate($img, 255, 255, 255);
    $textcolor = imagecolorallocate($img, 0, 0, 0);
// Add some text
$textColor = imagecolorallocate($img, 0, 0, 0);
imagestring($img, $fontSize, 900, 50,'COMMISSION REPORT', $textColor);
imagestring($img, $fontSize, 1, 100,'Member User Name :', $textcolor);


if($member_status == 'Inactive'){
	$redColor = imagecolorallocate($img, 236, 74, 74); // Red color
    imagestring($img, $fontSize, 350, 100, $member_status, $redColor);
}
imagestring($img, $fontSize, 180, 100,$customer_name, $textcolor);
imagestring($img, $fontSize, 380, 100,'', $textcolor);
imagestring($img, $fontSize, 530, 100,'Date and Time :', $textcolor);
imagestring($img, $fontSize, 780, 100,date('Y-m-d H:i'), $textcolor);
$level1_count = get_level_1_users_count_report($customer,$from,$to);
 $membership_level = explode(',',get_membership_level($level1_count));
    $ml_value = $membership_level[0];
    $ml_key = $membership_level[1];
	imagestring($img, $fontSize, 1, 130,'Membership Level :', $textcolor);
	imagestring($img, $fontSize, 180, 130,$ml_value, $textcolor);
imagestring($img, $fontSize, 380, 130,'Start date    :', $textcolor);
	imagestring($img, $fontSize, 540, 130,$from, $textcolor);
	imagestring($img, $fontSize, 830, 130,'End date :', $textcolor);
	imagestring($img, $fontSize, 930, 130,$to, $textcolor);

	if($member_status == 'Terminated'){
		$redColor = imagecolorallocate($img, 236, 74, 74); // Red color
		imagestring($img, $fontSize, 540, 170, 'Terminated', $redColor);
	}else{
	imagestring($img, $fontSize, 900, 170,'Downline Customer information', $textcolor);
	imagestring($img, $fontSize, 1, 220,'User Name', $textcolor);
	imagestring($img, $fontSize, 170, 220,'Customer Type', $textcolor);
	imagestring($img, $fontSize, 380, 220,'Level below you', $textcolor);
	imagestring($img, $fontSize, 610, 220,'Spend this month', $textcolor);
	imagestring($img, $fontSize, 850, 220,'Remove VAT 15%', $textcolor);
	imagestring($img, $fontSize, 1050, 220,'Total excluding VAT', $textcolor);
	imagestring($img, $fontSize, 1310, 220,'Total Profit', $textcolor);
	imagestring($img, $fontSize, 1500, 220,'Percentage', $textcolor);
	imagestring($img, $fontSize, 1680, 220,'Rand Value', $textcolor);	
	$all_level_users = get_all_level_users_start($customer);
		$y=260;	
    $total_commission=0;
	if(!empty($all_level_users)){
	foreach($all_level_users as $users){
		$getUsers=get_userdata($users)->user_login;
		$getType=get_user_meta($users,'customer_type','true');
		$getLevel=get_level($users,$customer,0,0);
		$getAmount='R'.get_amount_spent($users,$from,$to);

	$level_percent = get_option("member_status_level_percentages");
		$level = get_level($users,$customer,0,0);
		$amount_spent = get_amount_spent($users,$from,$to);		
		$percentage = $level_percent[$level-1][$level][$ml_key];		
		// $commission = round(($amount_spent*($percentage/100)),2);
		$exclude_vat = round($amount_spent/115*15, 2);
		$total_without_vat=$amount_spent-$exclude_vat;
        $markup=round($total_without_vat/140*40,2);
		$commission = round(($markup*($percentage/100)),2);
		$total_commission += $commission;
		
	imagestring($img, $fontSize, 1, $y,$getUsers, $textcolor);
	imagestring($img, $fontSize, 170, $y,$getType, $textcolor);
	imagestring($img, $fontSize, 380, $y,$getLevel, $textcolor);
	imagestring($img, $fontSize, 610, $y,$getAmount, $textcolor);
	imagestring($img, $fontSize, 850, $y,$exclude_vat, $textcolor);

	imagestring($img, $fontSize, 1050, $y,$total_without_vat, $textcolor);
	imagestring($img, $fontSize, 1310, $y,$markup, $textcolor);
	imagestring($img, $fontSize, 1500, $y,$percentage.' %', $textcolor);
	imagestring($img, $fontSize, 1680, $y,'R '.$commission, $textcolor);
	$y+=40;
	    }
	}
	else{
		imagestring($img, $fontSize, 1, $y,'NO DATA FOUND', $textcolor);
	}
		$y+=40;

	imagestring($img, $fontSize, 1, $y,'Total Commission for selected period :', $textcolor);
	imagestring($img, $fontSize, 380, $y,$total_commission, $textcolor);
	imagestring($img, $fontSize, 1, ($y+40),'Commission paid to you last month :', $textcolor);
	imagestring($img, $fontSize, 380,($y+40),'R ', $textcolor);
	}

	//$filename=$customer_name;
	$filename=$customer_name.'--commission_report';
	header("Content-Disposition: attachment; filename=\"$filename.png\"");
// header('Content-Disposition: attachment; filename="commission_report.png"');
    header('Content-Type: image/png');

// Output the image
    imagepng($img);
// Clean up resources
    imagedestroy($img);
	}

// function create_commission_picture_report($customer,$from,$to,$data){
// 	$customer_name = get_userdata($customer)->user_login;
// 	$customer_email = get_userdata($customer)->user_email;
// 	// header('Content-Disposition: attachment;filename="test.png"');
// 	// $imageFileName = 'commission_report.png';
// 	// header('Content-Disposition: attachment; filename="' . $imageFileName . '"');
// 	// header('Content-Type: image/png');
// 	// header('Content-Length: ' . filesize($imageFileName));
// 	// $img = imagecreate(1800, 1500);
// 	$img = imagecreatetruecolor(1800, 1500);
// 	$fontSize = 5;
//     $string='COMMISSION REPORT';
// 	$textbgcolor = imagecolorallocate($img, 255, 255, 255);
//     $textcolor = imagecolorallocate($img, 0, 0, 0);
// 	imagestring($img, $fontSize, 900, 50,'COMMISSION REPORT', $textcolor);
// 	imagestring($img, $fontSize, 1, 100,'Member User Name :', $textcolor);
// 	imagestring($img, $fontSize, 180, 100,$customer_name, $textcolor);
// 	imagestring($img, $fontSize, 280, 100,'', $textcolor);
// 	imagestring($img, $fontSize, 380, 100,'Date and Time :', $textcolor);
// 	imagestring($img, $fontSize, 530, 100,date('Y-m-d H:i'), $textcolor);
// $level1_count = get_level_1_users_count_report($customer,$from,$to);

// 	$level1_count = get_level_1_users_count_report($customer,$from,$to); 
//     $membership_level = explode(',',get_membership_level($level1_count));
//     $ml_value = $membership_level[0];
//     $ml_key = $membership_level[1];
// 	imagestring($img, $fontSize, 1, 130,'Membership Level :', $textcolor);
// 	imagestring($img, $fontSize, 180, 130,$ml_value, $textcolor);
// 	imagestring($img, $fontSize, 380, 130,'Start date    :', $textcolor);
// 	imagestring($img, $fontSize, 540, 130,$from, $textcolor);
// 	imagestring($img, $fontSize, 830, 130,'End date :', $textcolor);
// 	imagestring($img, $fontSize, 930, 130,$to, $textcolor);
// 	imagestring($img, $fontSize, 900, 170,'Downline Customer information', $textcolor);
// 	imagestring($img, $fontSize, 1, 220,'User Name', $textcolor);
// 	imagestring($img, $fontSize, 170, 220,'Customer Type', $textcolor);
// 	imagestring($img, $fontSize, 380, 220,'Level below you', $textcolor);
// 	imagestring($img, $fontSize, 610, 220,'Spend this month', $textcolor);
// 	imagestring($img, $fontSize, 850, 220,'Remove VAT 15%', $textcolor);
// 	imagestring($img, $fontSize, 1050, 220,'Total excluding VAT', $textcolor);
// 	imagestring($img, $fontSize, 1310, 220,'Total Profit', $textcolor);
// 	imagestring($img, $fontSize, 1500, 220,'Percentage', $textcolor);
// 	imagestring($img, $fontSize, 1680, 220,'Rand Value', $textcolor);	
// 	$all_level_users = get_all_level_users_start($customer);
// 	$y=260;	
// 	if(!empty($all_level_users)){
// 	foreach($all_level_users as $users){
// 		$getUsers=get_userdata($users)->user_login;
// 		$getType=get_user_meta($users,'customer_type','true');
// 		$getLevel=get_level($users,$customer,0,0);
// 		$getAmount='R'.get_amount_spent($users,$from,$to);
// 	$level_percent = get_option("member_status_level_percentages");
// 	$level = get_level($users,$customer,0,0);
// 	$amount_spent = get_amount_spent($users,$from,$to);		
// 	$percentage = $level_percent[$level-1][$level][$ml_key];		
// 	// $commission = round(($amount_spent*($percentage/100)),2);
// 	$exclude_vat = round($amount_spent/115*15, 2);
// 	$total_without_vat=$amount_spent-$exclude_vat;
// 	$markup=round($total_without_vat/140*40,2);
// 	$commission = round(($markup*($percentage/100)),2);
// 	$total_commission += $commission;
// 	imagestring($img, $fontSize, 1, $y,$getUsers, $textcolor);
// 	imagestring($img, $fontSize, 170, $y,$getType, $textcolor);
// 	imagestring($img, $fontSize, 380, $y,$getLevel, $textcolor);
// 	imagestring($img, $fontSize, 610, $y,$getAmount, $textcolor);
// 	imagestring($img, $fontSize, 850, $y,$exclude_vat, $textcolor);
// 	imagestring($img, $fontSize, 1050, $y,$total_without_vat, $textcolor);
// 	imagestring($img, $fontSize, 1310, $y,$markup, $textcolor);
// 	imagestring($img, $fontSize, 1500, $y,$percentage.' %', $textcolor);
// 	imagestring($img, $fontSize, 1680, $y,'R '.$commission, $textcolor);
// 	$y+=40;
// 	    }
// 	}
// 	else{
// 		imagestring($img, $fontSize, 1, $y,'NO DATA FOUND', $textcolor);
// 	}

	
// 	$y+=40;
// 	imagestring($img, $fontSize, 1, $y,'Total Commission for selected period :', $textcolor);
// 	imagestring($img, $fontSize, 380, $y,$total_commission, $textcolor);
// 	imagestring($img, $fontSize, 1, ($y+40),'Commission paid to you last month :', $textcolor);
// 	imagestring($img, $fontSize, 380,($y+40),'R ', $textcolor);
// 	ob_start();
// 	imagepng($img);
// 	echo base64_decode($img);


// 	 Set the Content-Disposition header to trigger a download
// header('Content-Disposition: attachment; filename="test.png"');
// header('Content-Type: image/png');

// // Output the image
// imagepng($img);

// // Clean up resources
// imagedestroy($img);
// }

add_action('admin_menu', 'custom_profile_register_options_page');
function custom_profile_register_options_page() {
	add_options_page( 
		'Additional Settings',
		'Additional Settings',
		'manage_options',
		'custom-profile',
		'custom_profile_options_page'
	);
}

add_action( 'admin_init', 'custom_profile_register_settings' );
function custom_profile_register_settings() {
	global $wpdb;
	$type = array('B','P','S','U');
	foreach($type as $customer):
   		add_option( 'custom_profile_op_exp_date_'.$customer, '31');
   		register_setting( 'custom_profile_additional_settings', 'custom_profile_op_exp_date_'.$customer);
	endforeach;
	foreach($type as $customer):
   		add_option( 'custom_profile_op_member_status_'.$customer,'Qualified');
   		register_setting( 'custom_profile_additional_settings', 'custom_profile_op_member_status_'.$customer);
	endforeach;
	foreach($type as $customer):
   		add_option( 'purchase_threshold_amount_'.$customer,'295.26');
   		register_setting( 'purchase_threshold_settings', 'purchase_threshold_amount_'.$customer);
	endforeach;
}

function custom_profile_options_page(){
	screen_icon(); 
	$active_tab = isset( $_GET[ 'tab' ] ) ? $_GET[ 'tab' ] : 'user_profile'; 
        ?>         
        <h2 class="nav-tab-wrapper">
            <a href="?page=custom-profile&tab=user_profile" class="nav-tab <?php echo $active_tab == 'user_profile' ? 'nav-tab-active' : ''; ?>">User Profile Settings</a>
            <a href="?page=custom-profile&tab=purchase_amount" class="nav-tab <?php echo $active_tab == 'purchase_amount' ? 'nav-tab-active' : ''; ?>">Purchase Amount Settings</a>
        </h2>
  	<div>
		<form method="post" action="options.php">
		<?php
		if( $active_tab == 'user_profile' ) {?>
  		<h2>Additional Profile Settings</h2><?php
			global $wpdb;
           		settings_fields( 'custom_profile_additional_settings' ); ?>
			<h4>Expiry Date :</h4>
  			<p>Set the maximum number of days grace given to a customer (after date of registration or after the date the last minimum monthly purchase was made) before they become "Inactive"</p>
  			<table>
  			<tr valign="top">
  			<th scope="row"><label for="custom_profile_op_exp_date_B" >B type Customer</label></th>
  			<td><input type="text" id="custom_profile_op_exp_date_B" name="custom_profile_op_exp_date_B" value="<?php echo get_option("custom_profile_op_exp_date_B"); ?>" /></td>
  			</tr>
  			<tr valign="top">
  			<th scope="row"><label for="custom_profile_op_exp_date_P" >P type Customer</label></th>
  			<td><input type="text" id="custom_profile_op_exp_date_P" name="custom_profile_op_exp_date_P" value="<?php echo get_option("custom_profile_op_exp_date_P"); ?>" /></td>
  			</tr>
  			<tr valign="top">
  			<th scope="row"><label for="custom_profile_op_exp_date_S" >S type Customer</label></th>
  			<td><input type="text" id="custom_profile_op_exp_date_S" name="custom_profile_op_exp_date_S" value="<?php echo get_option("custom_profile_op_exp_date_S"); ?>" /></td>
  			</tr>
  			<tr valign="top">
  			<th scope="row"><label for="custom_profile_op_exp_date_U" >U type Customer</label></th>
  			<td><input type="text" id="custom_profile_op_exp_date_U" name="custom_profile_op_exp_date_U" value="<?php echo get_option("custom_profile_op_exp_date_U"); ?>" /></td>
  			</tr>
			</table>
			 <h4>Member Status :</h4>
  			<p>Set member status</p>
			<table>
  			<tr valign="top">
  			<th scope="row"><label for="custom_profile_member_status_B" >B type Customer</label></th>
			<td>
			<?php echo select_html($type = 'B'); ?>
			</td>
			</tr>
  			<tr valign="top">
  			<th scope="row"><label for="custom_profile_member_status_P" >P type Customer</label></th>
			<td>
			<?php echo select_html($type = 'P'); ?>
			</td>
			</tr>
  			<tr valign="top">
  			<th scope="row"><label for="custom_profile_member_status_S" >S type Customer</label></th>
			<td>
			<?php echo select_html($type = 'S'); ?>
			</td>
			</tr>
  			<tr valign="top">
  			<th scope="row"><label for="custom_profile_member_status_U" >U type Customer</label></th>
			<td>
			<?php echo select_html($type = 'U'); ?>
			</td>
			</tr>
			 </table> 
			<?php
        	} else if( $active_tab == 'purchase_amount' ) {
			global $wpdb;
			echo'<h2>Purchase Amount Settings</h2>';
           		settings_fields( 'purchase_threshold_settings' ); ?>
			<h4>Purchase threshold amount :</h4>
  			<p>Set the threshold amount a customer can purchase</p>
  			<table>
  			<tr valign="top">
  			<th scope="row"><label for="purchase_threshold_amount_B" >B type Customer</label></th>
  			<td><input type="text" id="purchase_threshold_amount_B" name="purchase_threshold_amount_B" value="<?php echo get_option("purchase_threshold_amount_B"); ?>" /></td>
  			</tr>
  			<tr valign="top">
  			<th scope="row"><label for="purchase_threshold_amount_P" >P type Customer</label></th>
  			<td><input type="text" id="purchase_threshold_amount_P" name="purchase_threshold_amount_P" value="<?php echo get_option("purchase_threshold_amount_P"); ?>" /></td>
  			</tr>
  			<tr valign="top">
  			<th scope="row"><label for="purchase_threshold_amount_S" >S type Customer</label></th>
  			<td><input type="text" id="purchase_threshold_amount_S" name="purchase_threshold_amount_S" value="<?php echo get_option("purchase_threshold_amount_S"); ?>" /></td>
  			</tr>
  			<tr valign="top">
  			<th scope="row"><label for="purchase_threshold_amount_U" >U type Customer</label></th>
  			<td><input type="text" id="purchase_threshold_amount_U" name="purchase_threshold_amount_U" value="<?php echo get_option("purchase_threshold_amount_U"); ?>" /></td>
  			</tr>
			</table>
<?php
        	} 
		submit_button();
		 ?>
  		</form>
  		</div>
<?php
}

add_action('admin_menu', 'member_status_settings');
function member_status_settings() {
	add_options_page( 
		'Member Status Settings',
		'Member Status Settings',
		'manage_options',
		'member-status',
		'member_status_options_page'
	);
}

add_action( 'admin_init', 'member_status_register_settings' );
function member_status_register_settings() {
	global $wpdb;
	$member_level_options =  array('BRONZE'=>'9 or less','SILVER'=>'10 or more','GOLD'=>'20 or more','PLATINUM'=>'30 or more','DIAMOND'=>'40 or more');
	if (!get_option('member_status_levels')) {
		add_option('member_status_levels',$member_level_options);
	}
	if (!get_option('member_status_level_percentages')) {
		$level_percent = array();
		for($j = 1; $j<=7; $j++){
			$percent = array();
			for($i=0; $i<5; $i++){
				array_push($percent,'0'); 
			}
			array_push($level_percent,array($j=>$percent));
		}
		add_option('member_status_level_percentages',$level_percent); 
	}
	if (!get_option('reward_levels')) {
		add_option('reward_levels',$member_level_options);
	}
	if (!get_option('reward_level_percentages')) {
		$level_percent = array();
		for($j = 1; $j<=5; $j++){
			$percent = array();
			for($i=0; $i<5; $i++){
				array_push($percent,'0'); 
			}
			array_push($level_percent,array($j=>$percent));
		}
		add_option('reward_level_percentages',$level_percent); 
	}
}

function member_status_options_page(){
	screen_icon();
	$active_tab = isset( $_GET[ 'tab' ] ) ? $_GET[ 'tab' ] : 'member_status'; 
?>
	<h2 class="nav-tab-wrapper">
	<a href="?page=member-status&tab=member_status" class="nav-tab <?php echo $active_tab == 'member_status' ? 'nav-tab-active' : ''; ?>">Member Status Level Settings</a>
	<a href="?page=member-status&tab=reward_table" class="nav-tab <?php echo $active_tab == 'reward_table' ? 'nav-tab-active' : ''; ?>">Reward Table</a>
</h2>
<?php
	global $wpdb;
	if( $active_tab == 'member_status' ) {
	?>
	<div class="wrap">
		<div class="notice is-dismissible" style=""> 
		<p><strong>Settings saved.</strong></p><button type="button" class="notice-dismiss"><span class="screen-reader-text">Dismiss this notice.</span></button>
		</div>
		<h1>Member Status Level Settings</h1>
		<div style="margin-top:20px;">
			<div style=""><h2>Commission Table</h2></div>
			<div style="">
				<table id="member_status" style = "border 1px solid black">
				<?php
				$member_status = get_option("member_status_levels");
				?>
				<tr class="status_level">
					<td>Member Status Level</td>
					<?php
					foreach ($member_status as $k=>$val){
					echo'<td class="status_level_name">'.$k.'</td>';
					}
					?>
				</tr>
				<tr class="level_count">
					<td>Number of ACTIVE People on your first Level</td>
					<?php
					foreach ($member_status as $k=>$val){
					echo'<td class="count">'.$val.'</td>';
					}
					?>
				</tr>
				<?php
				$test_levels = get_option("member_status_level_percentages");
				foreach ($test_levels as $val){	
				 	echo'<tr class="percent">';
					foreach ($val as $k=>$v){
						echo'<td>Level'.' '.$k.' '.'Percentage</td>'; 
						foreach($v as $per){							
							echo'<td class="sel">
								<select>';
								for($i=0; $i<=25; $i++){
								?>
							<option value="<?php echo $i; ?>" <?php if($per == $i) echo 'selected == "selected" '; ?>><?php echo $i; ?>%</option>
								<?php
								}
								echo'</select></td>';
						} 
					}						
					echo'</tr>';
				}
				?>
			</table> 
			</div>
		</div>			
			<div class="sub">
				<input id="status_table_submit" class="button button-primary" type="button" value ="Save Changes"/>
			</div>
	</div>
	<?php
	} else if( $active_tab == 'reward_table' ) {
		global $wpdb; ?>
		<div class="wrap">
		<div class="notice is-dismissible" style=""> 
		<p><strong>Settings saved.</strong></p><button type="button" class="notice-dismiss"><span class="screen-reader-text">Dismiss this notice.</span></button>
		</div>
		<h1>Reward Level Settings</h1>
		<div style="margin-top:20px;">
			<div style=""><h2>Rewards Table</h2></div>
			<div style="">
				<table id="reward_table" style = "border 1px solid black">
				<?php
				$member_status = get_option("reward_levels");				
				?>
				<tr class="reward_level">
					<td>Reward Level</td>
					<?php
					foreach ($member_status as $k=>$val){
					echo'<td class="reward_level_name">'.$k.'</td>';
					}
					?>
				</tr>
					<?php
					?>
				<?php
		$test_levels = get_option("reward_level_percentages");
		echo "<pre>";
				foreach ($test_levels as $val){	
				 	echo'<tr class="percent">';
					foreach ($val as $k=>$v){
						echo'<td>Level'.' '.$k.'</td>'; 
						foreach($v as $per){														
								// echo '<td class="sel"><input type="text" name="level_percent" value="' . $per . '"></td>';
								echo'<td class="sel">
								<select>';
								for($i=0; $i<=25; $i++){
								?>
							<option value="<?php echo $i; ?>" <?php if($per == $i) echo 'selected == "selected" '; ?>><?php echo $i; ?>%</option>
								<?php
								}
								echo'</select></td>';
						} 
					}							
					echo'</tr>';
				}
				?>
			</table> 
			</div>
		</div>		
			<div class="sub">
				<input id="reward_table_submit"  class="button button-primary" type="button" value ="Save Changes" name="submit"/>
			</div>
		</div>
	<?php
	// reward_table(1716);	
}
}

function reward_table($user_id,$from,$to){
	
global $wpdb;

$admin_info = get_userdata(1);
$admin_email = $admin_info->user_email;
// foreach ($wpdb->get_results("SELECT ID, user_login, display_name FROM $wpdb->users ORDER BY ID") as $user){
    // $user_id = $user->ID;
	// $user_id = 1716;
// print_r($user);
    $user_info = get_userdata($user_id);	
    $member_status = get_user_meta($user_id, 'member_status', true);
	$reward_level = get_user_meta($user_id, 'reward_level', true);
	$customer_type = get_user_meta($user_id,'customer_type',true);

    if ($member_status === 'Active' &&  $customer_type != 'B') {		
		$current_date = current_time('Y-m-d');		
		$date_30_days_ago = date('Y-m-d', strtotime('-30 days'));

		// $level1_count = get_level_1_users_count_report($user_id,$from,$to); 
		$level1_count = get_level_1_users_count_report($user_id,$from,$to);
		$membership_level = explode(',',get_membership_level($level1_count));
		
		$ml_value = $membership_level[0];
		$ml_key   = $membership_level[1];
		// $user_id=1716;
		$all_level_users = get_all_level_users_start($user_id);
        $total = 0;

		$level_percent = get_option("reward_level_percentages");
		$percentage = $level_percent[$reward_level-1][$reward_level][$ml_key];

		$amount_spent = get_amount_spent($all_level_users,$date_30_days_ago,$current_date);	

		$total += $amount_spent;		
		$exclude_vat = round($total/115*15, 2);
		$total_without_vat=$total-$exclude_vat;
		$markup=round($total_without_vat/140*40,2);
		$total_reward = round(($markup*($percentage/100)),2);

		if( $level1_count >= 10 || $total > 50000 ){
			$consecutive_months = get_user_meta( $user_id, 'consecutive_months', true );		
			if($consecutive_months == '4'){		
				$reward_level = get_user_meta( $user_id, 'reward_level', true );
				update_user_meta($user_id,'consecutive_months', '0');
				if ($reward_level != '5') {
					update_user_meta( $user_id, 'reward_level', (int)$reward_level+1);
				}				
			}else{
				update_user_meta($user_id,'consecutive_months', (int)$consecutive_months+1);
				$total_reward = 0;
			}			
		}
		else{
			update_user_meta($user_id,'consecutive_months', '0');
			$total_reward = 0;
		}	
	}	
$rewards=[$total_reward , $reward_level];
     return $rewards;
}

function select_html($type){
	global $wpdb;
	$html = '<select id="custom_profile_op_member_status_'.$type.'" name="custom_profile_op_member_status_'.$type.'">';
	$html .= '<option value="Active"'; 
	if (get_option("custom_profile_op_member_status_".$type) == "Active")
	$html .= 'selected="selected"'; 
	$html .= '>Active</option>';
	$html .= '<option value="Inactive"'; 
	if (get_option("custom_profile_op_member_status_".$type) == "Inactive")
	$html .= 'selected="selected"'; 
	$html .= '>Inactive</option>';
	$html .= '<option value="Qualified"'; 
	if (get_option("custom_profile_op_member_status_".$type) == "Qualified")
	$html .= 'selected="selected"'; 
	$html .= '>Qualified</option>';
	$html .= '<option value="Terminated"'; 
	if (get_option("custom_profile_op_member_status_".$type) == "Terminated")
	$html .= 'selected="selected"'; 
	$html .= '>Terminated</option>';
	$html .= '</select>';
	return $html;
}
/****************Additional Settings Section Ends**********************/

/*Add additional fields in admin user profile/edit page -starts*/

add_action( 'show_user_profile', 'custom_additional_profile_fields' );       
add_action( 'edit_user_profile', 'custom_additional_profile_fields' );
        
function custom_additional_profile_fields( $user ) {   
?>
<h3>Extra Profile Information</h3>
	<table class="form-table">
		<tr>
			<th><label for="userid">User Id</label></th>
			<td>
				<input type="text" name="user_id" id="user_id" value="<?php echo esc_attr( $user->ID ); ?>" class="regular-text"  readonly/><br />
				<span class="description">User Id cannot be changed.</span>
			</td>
		</tr>
		<tr>
			<th><label for="joining_date">Joining Date</label></th>
			<td>
				<input type="text" name="joining_date" id="joining_date" value="<?php echo esc_attr( date("Y-m-d", strtotime($user->user_registered)) ); ?>" class="regular-text" readonly/><br />
				<span class="description">Joining date(Y-m-d) cannot be changed.</span>
			</td>
		</tr>
		<tr>
			<th><label for="expirydate">Expiry Date</label></th>
			<td>
				<input type="text" name="expiry_date" id="expiry_date" value="<?php echo esc_attr( get_user_meta( $user->ID, 'expiry_date', 'true' ) ); ?>" class="regular-text"/><br />
			</td>
		</tr>
		<tr>
			<th><label for="membershiplevel">Membership level</label></th>
			<td>
				<input type="text" name="membership_level" id="membership_level" value="<?php echo esc_attr( get_user_meta( $user->ID, 'membership_level', 'true' ) ); ?>" class="regular-text" /><br />
			</td>
		</tr>
		<tr>
			<th><label for="memberstatus">Member Status</label></th>
			<td>
				<input type="text" name="member_status" id="member_status" value="<?php echo esc_attr( get_user_meta( $user->ID, 'member_status', 'true' ) ); ?>" class="regular-text" /><br />
			</td>
		</tr>
		<tr>
			<th><label for="memberstatus">Genealogy Level</label></th>
			<td>
				<input type="text" name="genealogy_level" id="genealogy_level" value="<?php echo esc_attr( get_user_meta( $user->ID, 'genealogy_level', 'true' ) ); ?>" class="regular-text" /><br />
				<span class="description">This is the number of levels below the customer that commissions will be paid on.</span>
			</td>
		</tr>
		<tr>
			<th><label for="memberstatus">Cell Number</label></th>
			<td>
				<input type="text" name="cell_number" id="cell_number" value="<?php echo esc_attr( get_user_meta( $user->ID, 'cell_number', 'true' ) ); ?>" class="regular-text" /><br />
			</td>
		</tr>
	<?php
    $select = get_user_meta( $user->ID, 'select_number', true );
     ?>
	 	<tr>
			<th><label for="select">This your contact number</label></th>
				<td>
					<input type="radio" class="selectradio" name="select_number" id="select_yes" <?php checked( $select, 'yes' ); ?> value="yes" >Yes
					<input type="radio" class="selectradio" name="select_number" id="select_no" <?php checked( $select, 'no' ); ?>value="no">No<br>				
				</td>
		</tr>
       	<tr>    
			<th><label for="select"></label></th>
				<td>
					<select name="your_parent" id="your_parent" hidden="true" class="box" >
						<option value=""></option>
					</select>
				</td>
		</tr>         
	</table>

<h3>Bank Account Details</h3>
	<table class="form-table">
		<tr>
			<th><label for="bankname">Name of Bank</label></th>
			<td>
				<input type="text" name="bank_name" id="bank_name" value="<?php echo esc_attr( get_user_meta( $user->ID, 'bank_name', 'true' ) ); ?>" class="regular-text" /><br />
				
			</td>
		</tr>
		<tr>
			<th><label for="bankaccountnumber">Bank Account Number</label></th>
			<td>
				<input type="text" name="bank_account_number" id="bank_account_number" value="<?php echo esc_attr( get_user_meta( $user->ID, 'bank_account_number', 'true' ) ); ?>" class="regular-text" /><br />
				
			</td>
		</tr>
		<tr>
			<th><label for="branch">Branch Name or Branch Code</label></th>
			<td>
				<input type="text" name="bank_branch" id="bank_branch" value="<?php echo esc_attr( get_user_meta( $user->ID, 'bank_branch', 'true' ) ); ?>" class="regular-text" /><br />
				
			</td>
		</tr>
		<tr>
			<th><label for="account_holder">Name of account holder</label></th>
			<td>
				<input type="text" name="account_holder" id="account_holder" value="<?php echo esc_attr( get_user_meta( $user->ID, 'account_holder', 'true' ) ); ?>" class="regular-text" /><br />				
			</td>
		</tr>
	</table>

<input type="hidden" id="test_trigger"/> 
<?php       
}

add_action('edit_user_profile_update', 'update_extra_profile_fields');
add_action('personal_options_update', 'update_extra_profile_fields');
 
 function update_extra_profile_fields($user_id) {
        	update_user_meta($user_id, 'expiry_date', trim( $_POST['expiry_date']));
        	update_user_meta($user_id, 'membership_level', $_POST['membership_level']);
        	update_user_meta($user_id, 'member_status', $_POST['member_status']);
        	update_user_meta($user_id, 'genealogy_level', $_POST['genealogy_level']);
			update_user_meta($user_id, 'cell_number', $_POST['cell_number']);
			update_user_meta($user_id, 'select_number', $_POST['select_number']);
			update_user_meta($user_id, 'your_parent', $_POST['your_parent']);
        	update_user_meta($user_id, 'bank_name', $_POST['bank_name']);
        	update_user_meta($user_id, 'bank_account_number', $_POST['bank_account_number']);
        	update_user_meta($user_id, 'bank_branch', $_POST['bank_branch']);
        	update_user_meta($user_id, 'account_holder', $_POST['account_holder']);
 }


/*Disable profile fields for customers*/
add_action('admin_init', 'user_profile_fields_disable');
 function user_profile_fields_disable() {
 
    global $pagenow; 
    // apply only to user profile or user edit pages
    if ($pagenow!=='profile.php' && $pagenow!=='user-edit.php') {
        return;
    } 
    // do not change anything for the administrator
    if (current_user_can('administrator')) {
        return;
    } 
    add_action( 'admin_footer', 'user_profile_fields_disable_js' );
}

/**
 * Disables selected fields in WP Admin user profile (profile.php, user-edit.php)
 */
function user_profile_fields_disable_js() {
	?>
		<script>
			jQuery(document).ready( function($) {
			$('#expiry_date').prop('readonly',true);
			$('#membership_level').prop('readonly',true);
			$('#member_status').prop('readonly',true);
			$('#genealogy_level').prop('readonly',true);
			$('#customer_type option:not(:selected)').remove();	
		
			});
		</script>
	<?php
	}
	/*Disable profile fields for customers*/

add_filter('woocommerce_disable_admin_bar', '_wc_disable_admin_bar', 10, 1);
 
function _wc_disable_admin_bar($prevent_admin_access) {
    if (!current_user_can('customer')) {
        return $prevent_admin_access;
    }
    return false;
}

add_filter('woocommerce_prevent_admin_access', '_wc_prevent_admin_access', 10, 1);
 
function _wc_prevent_admin_access($prevent_admin_access) {
    if (!current_user_can('customer')) {
        return $prevent_admin_access;
    }
    return false;
}

add_action( 'wp_loaded','genealogy_download');
require_once  MLM_PLUGIN_PATH.'vendor/autoload.php';

function genealogy_download() {
    if ( isset( $_GET['download_gen'] ) ) {
		
	global $wpdb;
	
	// $customer = $_GET['customer'];
	// echo $customer;
	// die;
	$selected_date = $_GET['download_gen'];
	$customer_name=$_GET['name'];
	$customerId=$_GET['nameid'];
	// echo $customerId;
	// die;
	$date = explode('/',$selected_date);
	// print_r($selected_date);
	// die;
	$months = array('01'=>'JANUARY', '02'=>'FEBRUARY', '03'=>'MARCH', '04'=>'APRIL', '05'=>'MAY', '06'=>'JUNE', '07'=>'JULY', '08'=>'AUGUST', '09'=>'SEPTEMBER', '10'=>'OCTOBER', '11'=>'NOVEMBER','12'=>'DECEMBER');
	$YM = $date[1].' '.$months[$date[0]];
	$member_status = get_user_meta($customerId,'member_status',true);
	// print_r($member_status);
	// die;	
////
// $genealogy_level = 3;
// for($i=1; $i<=$genealogy_level; $i++){
	
// 	}
////
// 	$member_status = get_user_meta($customer_name,'member_status',true);
// // echo $member_status;
// die;
	// if( current_user_can('administrator') ) {
		
	// 	$current_user = wp_get_current_user();	
	// 	// print_r($current_user);
	// 	// die;	
	// 	$admin = $current_user->ID;
	// 	// print_r($admin);
	// 	// die;	
	// 	$sponsors = array();
	// 	$count = '';	
	// 	foreach ( $wpdb->get_results("SELECT * FROM $wpdb->users ") as $user ) :
	// 	// 	print_r($user);
	// 	// die;	
	// 		$count = 1;
	// 		$sponsor = get_user_meta($user->ID,'your_sponsor',true);
	// 	// print_r($user);
	// 	// die;	
	// 		if($user->ID != $admin){
	// 			array_push($sponsors,array("id"=>$user->ID,"sponsor"=>$sponsor) );
	// 			// print_r($sponsors);
	// 			// die;
	// 		}
			
	// 	endforeach;
	

		// print_r($sponsors);
		// echo "<br>";
		// echo $count ."count";
		// echo "<br>";
		// echo $admin."admin";
		// die;

		// $get_sponsor_result = get_sponsor($sponsors,$count,$admin);
		// print_r($get_sponsor_result);
		// die;
		// $admin_array = $get_sponsor_result['admin_level'];
		// $levels = $get_sponsor_result['levels'];
		// $total_levels = max($levels); 
		// $selected_user = $admin;
		// print_r($selected_user);
		// die;	
		
		
	// }else {
	// 	$current_user = wp_get_current_user();
	// 	$total_levels = get_user_meta($current_user->ID,'genealogy_level',true);
	// 	$selected_user = $current_user->ID;	
	// 	// echo $selected_user;
	// 	// die;	
	// }

	// $customer = $_GET['customer'];
	// echo $customer;
	// die;
		// $genealogy_level = $total_levels;
		// $members_list = [];
		// array_push($members_list,$selected_user);
		// // print_r($genealogy_level);
		// // die;
		// $query = "";		
		// $query .= "SELECT ";
		// for($i=0; $i< $genealogy_level; $i++){
		// 	$j = $i+1;
		// 	$query.= " um".$i.".user_id as LEVEL".$j.",um".$i.".meta_value AS SP".$j;
		// 	if( $genealogy_level != ($i+1) ){
		// 		$query.= ",";	
		// 	}
	// 	// }
	// 	$query.=" FROM wp_users u INNER JOIN wp_usermeta um0 ON (u.id = um0.meta_value AND um0.meta_key = 'your_sponsor' AND um0.meta_value = '$selected_user')";
	// 	for($i=1; $i< ($genealogy_level+1); $i++){
	// 		$j = $i-1;
	// 		$query .= " LEFT JOIN wp_usermeta um".$i." ON (um".$i.".meta_value = um".$j.".user_id AND um".$i.".meta_key = 'your_sponsor')";		
	// 	}		
	// 	//echo $query;		
	// 	$return = [];
	// 	foreach ( $wpdb->get_results("$query") as $row ):			

	// 		$_data = [];
    // 			$heirarchy = [];
    // 			foreach ($row as $k=>$v)
    // 			{ 
    //     			 $sp = str_replace('SP', '', $k);
    //     			if (is_numeric($sp))
    //     			{
    //         				if (! isset($heirarchy[$sp])) $heirarchy[$sp] = [];      
    //         				$heirarchy[$sp]['SP'] = $v; 
    //     			}
    //     			$level = str_replace('LEVEL', '', $k);
    //     			if (is_numeric($level))
    //     			{
    //         				if (! isset($heirarchy[$level])) $heirarchy[$level] = []; 
					
    //         				$heirarchy[$level]['LEVEL'] = $v; 
	// 				if(isset($v)) { array_push($members_list,$v); }
    //     			}
    // 			}
    // 			if (isset($heirarchy[1])) {
    //     			$_data[$heirarchy[1]['SP']] = get_heirarchy_data($heirarchy);
   	// 		}
    // 			$return = array_replace_recursive($return, $_data);
	// 	endforeach;

	// $gen_array = $return;
// echo "test";
	// die;
	// print_r($total_levels);
	// die;
	$objPHPExcel = new Spreadsheet();
	$sheet1  = $objPHPExcel->getActiveSheet();
    $sheet1->setTitle('genealogy_report');
    $sheet1->setCellValue('A1', 'Hello World !');

	 $col = 'A';
	 $sheet1->getDefaultRowDimension()->setRowHeight(75);
	// for($i=0; $i<=$total_levels; $i++){
		$sheet1->getColumnDimension($col)->setWidth(25);
		$sheet1->getStyle($col)->getFont()->setName('Times New Roman')->setSize(12);
	// 	$col++;
	// }
	$sheet1->getStyle('A1:'.$col.'1')->getFont()->setBold(true)->getColor()->setRGB('#0000FF');
	$sheet1->SetCellValue('A1', $YM.PHP_EOL.PHP_EOL.PHP_EOL.'GENEALOGY');

    $sheet1->SetCellValue('B1','');
	$col = 'B';
	$genealogy_level = 3;
	for($i=1; $i<=$genealogy_level; $i++){
		$col++;	
		$sheet1->getDefaultRowDimension()->setRowHeight(75);
		$sheet1->getColumnDimension($col)->setWidth(25);
		$sheet1->getStyle($col)->getFont()->setName('Times New Roman')->setSize(12);
		$sheet1->getStyle('A1:'.$col.'1')->getFont()->setBold(true)->getColor()->setRGB('#0000FF');
		$sheet1->SetCellValue($col.'1', 'LEVEL'.$i);
		$sheet1->SetCellValue('B1','');
		}
		
		switch ($member_status) {
			case "Active":
				$bgcolor = "#2eb82e";
				break;
			case "Qualified":
				$bgcolor = "#00b8e6";
				break;
			case "Inactive":
				$bgcolor = "#ff9900";
				break;
			case "Terminated":
				$bgcolor = "#cc0000";
				break;
			default:
				$bgcolor = "#a6a6a6";
				break;
		}
	
// Set the background color (fill) for cell 'A3'
$cellStyle = $sheet1->getStyle('A3');
$cellStyle->getFill()->setFillType(\PhpOffice\PhpSpreadsheet\Style\Fill::FILL_SOLID);
$cellStyle->getFill()->getStartColor()->setARGB($bgcolor);

// You can also set the font color
$cellStyle->getFont()->getColor()->setRGB('#0000FF');

$sheet1->setCellValue('A3', $customer_name);

		// $sheet1->getStyle('A')->getFill()->setFillType(\PhpOffice\PhpSpreadsheet\Style\Fill::FILL_SOLID)->getStartColor()
		// ->setARGB('ffffff');
		// $sheet1->getStyle('A3:'.$col.'3')->getFont()->setBold(true)->getColor()->setRGB('#0000FF');
		// $sheet1->SetCellValue('A3',$customer_name);
    // $col = 'A';
	// for($i=1; $i<=$total_levels; $i++){
	// $col++;	
	// $sheet1->SetCellValue($col.'1', 'LEVEL'.$i);
	// }
	// $sheet1->freezePane($col."2");
	// $col = 'A';
	// $levels = $gen_array;
	// $test = makeMarkUp($levels);
// print_r($levels);
// die;


// $sheet1->getStyle('A2:'.$col.'2')->getFont()->setBold(true)->getColor()->setRGB('#0000FF');
// $sheet1->SetCellValue('A2','');

// $sheet1->getStyle('A')->getFill()->setFillType(\PhpOffice\PhpSpreadsheet\Style\Fill::FILL_SOLID)->getStartColor()
// ->setARGB('ffffff');
// $sheet1->getStyle('A3:'.$col.'3')->getFont()->setBold(true)->getColor()->setRGB('#0000FF');
// $sheet1->SetCellValue('A3',$customer_name);

	// foreach ($test as $t)
	// {	
	// 	if($t[1] != $prev){
	// 		$user_id = $t[1];
	// 		$details = user_level_details($user_id,$selected_date); 
	// 		$sheet1->SetCellValue((string)$t[0], $details['first_name'].' '.$details['last_name'].PHP_EOL."Username:".$details['user_name'].PHP_EOL."Customer Id:".$details['user_id'].PHP_EOL."Customer Type:".$details['customer_type'].PHP_EOL."Customer Status:".$details['member_status'].PHP_EOL."Purchase Value:".$details['purchase_value']);
	// 	}
	// 	$prev = $t[1];
	// }
	// $highRow = $sheet1->getHighestRow();
	// $collapse_row = array();
	// $col = 'D'; $z=1;
	// for($i=2; $i<=$total_levels; $i++){
	// 	//$i=2;
	// 	//if($i == 2) 
	// 		for($j=4; $j<= $highRow; $j++){
	// 			$val = $sheet1->getCell($col.$j)->getValue();
	// 			if(!empty($val)){
	// 			 array_push($collapse_row,$j);	
	// 			}
	// 		}			
	// 		for($cl = 0; $cl<count($collapse_row); $cl++){
	// 			$prev = $collapse_row[$cl];
	// 			// $sheet1->getRowDimension($prev)->setOutlineLevel($z)->setVisible(false)->setCollapsed(true);
	// 		}		
	// 	$col++; $z++;
	// 	$collapse_row = [];
	// }
	
	$filename='--genealogy_report';
	ob_end_clean();
	header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
	// header('Content-Disposition: attachment;filename="commission report.xlsx"');
	header('Content-Disposition: attachment; filename="' . $filename . '.xlsx"');

	header('Cache-Control: max-age=0');
	// If you're serving to IE 9, then the following may be needed
	header('Cache-Control: max-age=1');
	// If you're serving to IE over SSL, then the following may be needed
	header ('Expires: Mon, 26 Jul 1997 05:00:00 GMT'); // Date in the past
	header ('Last-Modified: '.gmdate('D, d M Y H:i:s').' GMT'); // always modified
	header ('Cache-Control: cache, must-revalidate'); // HTTP/1.1
	header ('Pragma: public'); // HTTP/1.0
	$writer = new Xlsx($objPHPExcel);
	$writer->save('php://output');
		exit;
	// require_once dirname(__FILE__) . '/Classes/PHPExcel.php';
	


	// $objPHPExcel = new PHPExcel();
	// $styleArray = array(
	// 				'borders' => array(
	// 					'allborders' => array(
	// 						'style' => PHPExcel_Style_Border::BORDER_THIN
	// 					)
	// 				)
	//       		);

	// $objPHPExcel->getDefaultStyle()
	//     ->applyFromArray($styleArray)
	//     ->getAlignment()
	//     ->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER)
	//     ->setWrapText(true);

	// $col = 'A';
	// $objPHPExcel->getActiveSheet()->getDefaultRowDimension()->setRowHeight(75);
	// for($i=0; $i<=$total_levels; $i++){
	// 	$objPHPExcel->getActiveSheet()->getColumnDimension($col)->setWidth(25);
	// 	$objPHPExcel->getActiveSheet()->getStyle($col)->getFont()->setName('Times New Roman')->setSize(12);
	// 	$col++;
	// }
	// $objPHPExcel->getActiveSheet()->getStyle('A1:'.$col.'1')->getFont()->setBold(true)->getColor()->setRGB('#0000FF');
	// $objPHPExcel->getActiveSheet()->SetCellValue('A1', $YM.PHP_EOL.PHP_EOL.PHP_EOL.'GENEALOGY');

	// $col = 'A';
	// for($i=1; $i<=$total_levels; $i++){
	// $col++;	
	// $objPHPExcel->getActiveSheet()->SetCellValue($col.'1', 'LEVEL'.$i);
	// }
	// $objPHPExcel->getActiveSheet()->freezePane($col."2");
	// $col = 'A';
	// $levels = $gen_array;
	// $test = makeMarkUp($levels);
	// foreach ($test as $t)
	// {	
	// 	if($t[1] != $prev){
	// 		$user_id = $t[1];
	// 		$details = user_level_details($user_id,$selected_date); 
	// 		$objPHPExcel->getActiveSheet()->SetCellValue((string)$t[0], $details['first_name'].' '.$details['last_name'].PHP_EOL."Username:".$details['user_name'].PHP_EOL."Customer Id:".$details['user_id'].PHP_EOL."Customer Type:".$details['customer_type'].PHP_EOL."Customer Status:".$details['member_status'].PHP_EOL."Purchase Value:".$details['purchase_value']);
	// 	}
	// 	$prev = $t[1];
	// }
	
	// $highRow = $objPHPExcel->getActiveSheet()->getHighestRow();
	// $collapse_row = array();
	// $col = 'D'; $z=1;
	// for($i=2; $i<=$total_levels; $i++){
	// 	//$i=2;
	// 	//if($i == 2) 
	// 		for($j=4; $j<= $highRow; $j++){
	// 			$val = $objPHPExcel->getActiveSheet()->getCell($col.$j)->getValue();
	// 			if(!empty($val)){
	// 			 array_push($collapse_row,$j);	
	// 			}
	// 		}			
	// 		for($cl = 0; $cl<count($collapse_row); $cl++){
	// 			$prev = $collapse_row[$cl];
	// 			//$objPHPExcel->getActiveSheet()->getRowDimension($prev)->setOutlineLevel($z)->setVisible(false)->setCollapsed(true);
	// 		}		
	// 	$col++; $z++;
	// 	$collapse_row = [];
	// }
	// // Redirect output to a client’s web browser (Excel2007)
	// header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
	// header('Content-Disposition: attachment;filename="admin_genealogy.xlsx"');
	// header('Cache-Control: max-age=0');
	// // If you're serving to IE 9, then the following may be needed
	// header('Cache-Control: max-age=1');
	// // If you're serving to IE over SSL, then the following may be needed
	// header ('Expires: Mon, 26 Jul 1997 05:00:00 GMT'); // Date in the past
	// header ('Last-Modified: '.gmdate('D, d M Y H:i:s').' GMT'); // always modified
	// header ('Cache-Control: cache, must-revalidate'); // HTTP/1.1
	// header ('Pragma: public'); // HTTP/1.0
	// $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
	// $objWriter->save('php://output');
	// exit;            
    }
}

function get_sponsor($sponsors,$count,$admin){
	$admin_level = array();
	$levels = array();	
		for($i=0; $i< count($sponsors); $i++){
			$flag = 0; $count = 1;
			if($sponsors[$i]['sponsor'] != ""){ 
				$level = get_level($sponsors[$i]['sponsor'],$admin,$flag,$count);	

			}else{
				$level = 0;
			}			
			array_push($admin_level,array("user"=>$sponsors[$i]['id'],"level"=>$level));
			array_push($levels,$level);	
		}	
	return array("admin_level"=>$admin_level, "levels"=>$levels);
}

function get_level($sponsor,$admin,$flag,$count){ 
	global $wpdb;
	if ($flag == 1) {  return $count; }
	if( (!empty($sponsor)) and ($sponsor != $admin)){
		$count++; 	
		$flag = 0; 
		$sponsor = get_user_meta($sponsor,'your_sponsor',true); 
		if($sponsor == '') return 0; 			
		return get_level($sponsor,$admin,$flag,$count);	    
	}else{
		$flag = 1;
		return get_level($sponsor,$admin,$flag,$count);
	}
}

function user_level_details($user_id,$selected_date){
	global $wpdb;
	$date = $selected_date; 
	$date = explode('/',$date);
	$date = implode('-',array_reverse($date));
	$purchase_value = 0;
	$orders = get_posts( array(
		'numberposts' => -1,
		'meta_key'    => '_customer_user',
		'meta_value'  => $user_id,
		'post_type'   => wc_get_order_types( 'view-orders' ),
		'post_status' => array_keys( wc_get_order_statuses() )
	));

	if(!empty($orders)){
		foreach ( $orders as $order => $data ) { 
		$order_id = $data->ID;  
		$purchase_date = $data->post_date; 
			if( ($data->post_status == 'wc-completed') or ($data->post_status == 'wc-processing') ){
				if(date('Y-m',strtotime($purchase_date)) == $date){
					$order_data = new WC_Order( $order_id ); 	
					$purchase_amount = number_format( (float) $order_data->get_total() -$order_data->get_total_tax() -$order_data->get_total_shipping() - $order_data->get_shipping_tax(), wc_get_price_decimals(), '.', '' ); 
					$purchase_value =+ $purchase_amount;
				}
			}		
		} 
	}

if($purchase_value == '0'){ $purchase_value = '0.00'; }
	$details = [];
	$user_details = $wpdb->get_row("SELECT * FROM $wpdb->users WHERE `ID` = '$user_id'");
	$details['user_name'] = $user_details->user_login;
	$details['user_id'] = $user_details->ID;
	$details['first_name'] = get_user_meta($user_id,'first_name',true);
	$details['last_name'] = get_user_meta($user_id,'last_name',true);
	$details['customer_type'] = get_user_meta($user_id,'customer_type',true);
	$details['membership_level'] = get_user_meta($user_id,'membership_level',true);
	$details['member_status'] = get_user_meta($user_id,'member_status',true);
	$details['purchase_value'] = $purchase_value;
	return $details;
}

function makeMarkUp($levels) {  
	return gRender2($levels, 'A', 2, 0);
}

function gRender2($object, $x, $y , $flag){
	$return = [];
	$tx = $x;
	$tx++;
	if($flag == 1){ $y++; }
	foreach ($object as $key=>$value){
		$return[] = [$x.$y , $key];
		$temp = gRender2($value, $tx, $y ,1);
		for ($i = 0; $i < count($temp); $i++) { $return[] = [$x.$y, $key]; $y++; } /*$j= 0; while($j<5) { $y++; $j++; }*/
		$return = array_merge($return, array_values($temp));
		$y++;
	}
	return $return;
}

function get_level_1_users_count_report($user_id,$from,$to){
	global $wpdb;
	$count = 0;
	foreach ( $wpdb->get_results("SELECT * FROM $wpdb->usermeta WHERE `meta_key`= 'your_sponsor' AND `meta_value`='$user_id' ORDER BY user_id") as $level1user ) :

	$user = $level1user->user_id;
		if((get_user_meta($level1user->user_id,'member_status','true') == 'Active') and (get_user_meta($level1user->user_id,'customer_type','true') == 'P')){
			$user = $level1user->user_id;
			$purchase_value = get_amount_spent($user,$from,$to);
			if($purchase_value != '0'){
			$count = $count+1;
			}else{
				$count = $count+1;
			}		
		}
		else if( (get_user_meta($level1user->user_id,'member_status','true') == 'Active') and (get_user_meta($level1user->user_id,'customer_type','true') == 'B')){
			$user = $level1user->user_id;
			$purchase_value = get_amount_spent($user,$from,$to);
			if($purchase_value != '0'){	
			$count = $count+1; 
			}else{
				$count = $count+1;
			}
		}
		//  else{
		// 	$count = 0;
		// }
	endforeach;	
	return $count;
}

function get_membership_level($level1count){
	// print_r($level1count);
	$member_status = get_option("member_status_levels");
	$i=0;
	foreach ($member_status as $k=>$val){
		$val = explode(' ',$val);  
			if ($val[2]=='less'){ if($level1count <= $val[0]){ $membership_level = $k.','.$i; }}
			else if ($val[2]=='more'){ if($level1count >= $val[0]){ $membership_level = $k.','.$i;}}
		$i++;
	}
	// print_r($membership_level);
	// die;
	return $membership_level;
}

function get_all_level_users_start($user_id){
	global $wpdb;
	$genealogy_level = get_user_meta($user_id,'genealogy_level',true);
	$level = 1;
	$flag = 0;
	$levels = array();
	$all_levels = array();
	if($level <= $genealogy_level){
		foreach ( $wpdb->get_results("SELECT * FROM $wpdb->usermeta WHERE `meta_key`= 'your_sponsor' AND `meta_value`='$user_id' ORDER BY user_id") as $level1user ) :	

			if(get_user_meta($level1user->user_id,'member_status','true') == 'Active' || get_user_meta($level1user->user_id,'member_status','true') == 'Inactive' || get_user_meta($level1user->user_id,'member_status','true') == 'Qualified'){
				array_push($levels, $level1user->user_id);
				array_push($all_levels,$level1user->user_id);				
			}
			if($wpdb->get_var("SELECT COUNT(*) FROM $wpdb->usermeta WHERE `meta_key`= 'your_sponsor' AND `meta_value`='$level1user->user_id' ORDER BY user_id") > 0){ $flag = 1;}
		endforeach;
	}
	$all_level_users = get_all_level_users($levels,$flag,$level,$genealogy_level,$all_levels);
	return $all_level_users;
}

function get_all_level_users($levels,$flag,$level,$genealogy_level,$all_levels){ 
	global $wpdb;
	if ($flag == 0){ return $all_levels;  }
	if ($flag == 1){
		$level = $level+1;
		if($level > $genealogy_level){ return $all_levels;
		}else{
			$flag = 0; 
			$next_level = array();
			foreach($levels as $sponsor){ 
				foreach ( $wpdb->get_results("SELECT * FROM $wpdb->usermeta WHERE `meta_key`= 'your_sponsor' AND `meta_value`='$sponsor' ORDER BY user_id") as $user ) : 		
					if( (get_user_meta($user->user_id,'member_status','true') == 'Active') or (get_user_meta($user->user_id,'member_status','true') == 'Qualified')){ 
						array_push($next_level, $user->user_id);
						array_push($all_levels,$user->user_id);
					}
				endforeach;
				if(!empty($next_level)){ $flag = 1; }
			}

			// $all_levels_new = array();
			// foreach($all_levels as $new_array){
			// 	if((get_user_meta($new_array,'member_status','true') == 'Active') or (get_user_meta($new_array,'member_status','true') == 'Qualified')){
			// 		array_push($all_levels_new,$new_array);
			// 	}
			// }

			return get_all_level_users($next_level,$flag,$level,$genealogy_level,$all_levels);
		}
	}
}

function get_amount_spent($user,$from,$to){
	$purchase_value = 0;
	$orders = get_posts(array(
		'numberposts' => -1,
		'meta_key'    => '_customer_user',
		'meta_value'  => $user,
		'post_type'   => wc_get_order_types( 'view-orders' ),
		'post_status' => array_keys( wc_get_order_statuses())
	));
    $purchase_value = 0;                                                           
	if(!empty($orders)){
		foreach ( $orders as $order => $data ){ 
			$order_id = $data->ID;  
			$purchase_date = $data->post_date; 
			if( ($data->post_status == 'wc-completed') or ($data->post_status == 'wc-processing') ){
				if( (strtotime($purchase_date) >= strtotime($from) ) and (strtotime($purchase_date) <= strtotime($to) ) ){			
				$order_data = new WC_Order( $order_id ); 	
				$purchase_amount = number_format( (float) $order_data->get_total() -$order_data->get_total_tax() -$order_data->get_total_shipping() - $order_data->get_shipping_tax(), wc_get_price_decimals(), '.', '' );				
				$purchase_value =$purchase_value+$purchase_amount;					
				}
			}
		}
	}
	return $purchase_value;
}
// Calculate the timestamp for the last day of the current month
// $current_month_last_day = date('Y-m-d 11:20:00'); // 't' returns the last day of the current month
// echo $current_month_last_day;
// die;
// $timestamp = strtotime($current_month_last_day); // Convert to Unix timestamp
// // If the calculated timestamp is in the past, add one day (86400 seconds) to schedule it for the last day of the next month
// if ($timestamp < time()) {
//     $timestamp = strtotime('+1 month', $timestamp);
// }

$current_month_last_day = date('Y-m-d 12:10:00');
// 't' returns the last day of the current month
$timestamp = strtotime($current_month_last_day); // Convert to Unix timestamp
// If the calculated timestamp is in the past, add one day (86400 seconds) to schedule it for the last day of the next month
// echo $timestamp;
// echo "<br>";
// echo time();
// $year = date('Y');
// 		$month = date('M');
// 		$lastDay = getLastDayOfMonth($year, $month);
// 		echo $lastDay."<br>"; // Output: 31

// 		$current_month_last_day = date("".$year."-".$month."-".$lastDay."23:55:00"); 

// echo $current_month_last_day;
// 		// $current_month_last_day = date('Y-m-d 23:55:00');
// 		// $current_month_last_day = date('Y-m-d 12:10:00');
// 		 // 't' returns the last day of the current month
//         $timestamp = strtotime($current_month_last_day);
		
// die;
// add_action('my_custom_commission_cron_hook', 'commission_update_cron_exec');
// add_action('my_custom_status_cron_hook', 'status_update_cron_exec');
// // Activate the plugin
// register_activation_hook(__FILE__, 'activate_custom_cron_plugin');
// function activate_custom_cron_plugin() {
// 	date_default_timezone_set('Asia/Kolkata'); // Set the timezone to IST

// 	if (!wp_next_scheduled('my_custom_status_cron_hook')) {
//         wp_schedule_event(time() , 'daily', 'my_custom_status_cron_hook');
//     }
// 	if (!wp_next_scheduled('my_custom_commission_cron_hook')){
// 		// $year = date('Y');
// 		// $month = date('M');
// 		// $lastDay = getLastDayOfMonth($year, $month);
// 		// // echo $lastDay; // Output: 31
// 		// // $from = date("".$year."-".$month."-01 H:i:s");
// 		// // $to = date("Y-m-d 23:59:59",strtotime($date. "-1 day"));
// 		// $current_month_last_day = date("".$year."-".$month."-06 01:03:00");

// 		// // $current_month_last_day = date('Y-m-d 23:55:00');
// 		// // $current_month_last_day = date('Y-m-d 01:00:00');
// 		//  // 't' returns the last day of the current month
//         // $timestamp = strtotime($current_month_last_day); // Convert to Unix timestamp
//         // // If the calculated timestamp is in the past, add one day (86400 seconds) to schedule it for the last day of the next month
// 		// // echo $timestamp;
// 		// // echo time();
// 		// // die;
//         // if ($timestamp < time()) {
//         // $timestamp = strtotime('+1 month', $timestamp);
//         // }
//         // wp_schedule_event($timestamp, 'monthly', 'my_custom_commission_cron_hook');
// 		wp_schedule_event(time() , 'daily', 'my_custom_commission_cron_hook');
//     }
// } 

// // Deactivate the plugin
// register_deactivation_hook(__FILE__, 'deactivate_custom_cron_plugin');
// function deactivate_custom_cron_plugin() {
//     // Clear the scheduled cron job on plugin deactivation
//     wp_clear_scheduled_hook('my_custom_commission_cron_hook');
// 	wp_clear_scheduled_hook('my_custom_status_cron_hook');
// }


add_action('my_custom_cron_hook', 'commission_update_cron_exec'); 
add_action('my_custom_status_cron_hook', 'status_update_cron_exec');
// Activate the plugin
register_activation_hook(__FILE__, 'activate_custom_cron_plugin');

function activate_custom_cron_plugin() {
	date_default_timezone_set('Asia/Kolkata'); // Set the timezone to IST

	if (!wp_next_scheduled('my_custom_status_cron_hook')) {
        wp_schedule_event(time(), 'daily', 'my_custom_status_cron_hook');
    }
	    // $today = strtotime('today');
		// $next_occurrence = strtotime('05:15:00', $today);
		// if ($next_occurrence < time()) {
		// 	// If it's in the past, schedule it for tomorrow instead
		// 	$next_occurrence = strtotime('tomorrow 23:55:00');
		// }

		$last_day_of_month = strtotime('last day of this month');
		$next_occurrence_commission = strtotime('23:55:00', $last_day_of_month);
		if ($next_occurrence_commission < time()) {
			$last_day_of_next_month = strtotime('last day of next month');
			$next_occurrence_commission = strtotime('23:55:00', $last_day_of_next_month);
		}

		if (!wp_next_scheduled('my_custom_cron_hook')) {
			wp_schedule_single_event($next_occurrence, 'my_custom_cron_hook');
		}
}
// Deactivate the plugin
register_deactivation_hook(__FILE__, 'deactivate_custom_cron_plugin');
function deactivate_custom_cron_plugin() {
    // Clear the scheduled cron job on plugin deactivation
    wp_clear_scheduled_hook('my_custom_cron_hook');	
	wp_clear_scheduled_hook('my_custom_status_cron_hook');
}

function status_update_cron_exec(){
	// wp_mail("aditi.a.expinator@gmail.com","status Test","status Test mail");
	// die;
	// echo "echo";
	// exit();
	global $wpdb;	 
	$admin_info = get_userdata(1);
	$admin_email = $admin_info->user_email;
	foreach ( $wpdb->get_results("SELECT ID, user_login, display_name FROM $wpdb->users ORDER BY ID") as $user ) :	    
	$user_id = $user->ID;
	// echo "<pre>";
	// echo $user_id;
	$user_info = get_userdata($user_id);
	$user_email = $user_info->user_email;
	// $user_email = "aditi.a.expinator@gmail.com";

	$subject = "Account Warning - gwcorp.co.za\r\n";
	$header = "From: noreply@gwcorp.co.za\r\n"; 
	$header.= "Cc: admin@gwcorp.co.za\r\n";
	$header.= "Bcc: rfagunther@gmail.com\r\n";
	$header.= "MIME-Version: 1.0\r\n"; 
	$header .= 'Content-Type: text/html; charset=ISO-8859-1'; 
	$header.= "X-Priority: 1\r\n"; 

	// $level1_count = get_level_1_users_count_report($user_id,$from,$to);		        
	// $membership_level = explode(',',get_membership_level($level1_count));

	$member_status = get_user_meta($user_id,'member_status',true);
	if($member_status != "Terminated"){
		$today = date("Y-m-d");
		$purchase_date = '';
		$purchase_amount = '0';
		$expiry_date = get_user_meta($user_id,'expiry_date','true');
		$customer_type = get_user_meta($user_id,'customer_type','true');	
		$purchase_threshold_amount_P = get_option("purchase_threshold_amount_P");	 
		$purchase_threshold_amount_B = get_option("purchase_threshold_amount_B");
	if($expiry_date != ""){ 
		$diff = ( (strtotime($expiry_date) - strtotime($purchase_date))/(60 * 60 * 24) );
			switch($customer_type){
				case "P": 
				$new_expiry_date = date('Y-m-d', strtotime($today. ' + '.(get_option("custom_profile_op_exp_date_P")-1).' days'));
					if( (strtotime($purchase_date) == strtotime($expiry_date))  and ($diff <= get_option("custom_profile_op_exp_date_P"))and ($purchase_amount > $purchase_threshold_amount_P) ){ 
				
					if($member_status == 'Inactive'){
							$check = check_total_purchase_amount_P($all_orders);
							
							if($check == true){
							 update_user_meta($user_id, 'member_status','Active');
		 					 if(date('Y-m-d',strtotime($expiry_date. '+1 day')) == $today){
							 update_user_meta($user_id, 'expiry_date',$new_expiry_date);
							 }
							}
						}else{					
							 update_user_meta($user_id, 'member_status','Active');
								if(date('Y-m-d',strtotime($expiry_date. '+1 day')) == $today){
								update_user_meta($user_id, 'expiry_date',$new_expiry_date);
								}
							}
					}else{ 
						if(date('Y-m-d',strtotime($expiry_date. '+1 day')) == $today){
							if( ($member_status == 'Qualified') or ($member_status == 'Active') ){
							update_user_meta($user_id, 'member_status','Inactive');
							update_user_meta($user_id, 'expiry_date', $new_expiry_date);
							//send email - You are currently inactive, Please don't forget to double your purchase to become Active again
							$message = "You are currently inactive, Please don't forget to double your purchase to become Active again";	
							$message .= "<br>you cannot earn rewards while being Inactive.<br> To fix the problem your minimum purchase is now R".(2 * $purchase_threshold_amount_P);
							wp_mail($user_email, $subject, $message, $header);
							}else if($member_status == 'Inactive'){
							update_user_meta($user_id, 'member_status','Terminated');
							update_user_meta($user_id, 'expiry_date','0');

							//send email - The system terminates them, sends them an email and sms to notify them of termination and blocks them from logging in or purchasing
							// $message = "You have been terminated from our system, We are sorry to see you go, Thanks for your support";		
							$message = "We regret to inform you that your account has been <strong>Terminated</strong> from our system.Your membership has been terminated due to no activity for 3 months. Your access has been blocked, and you won't be able to log in or make any purchases using this account.";

							wp_mail($user_email, $subject, $message, $header);							
							}
						}
/***********************************************************************************************************************/

						if( (date('Y-m-d',strtotime($expiry_date. '-5 days')) == $today) or (date('Y-m-d',strtotime($expiry_date. '-3 days')) == $today)){
							// print_r($user_id);
							if( ($member_status == 'Qualified') or ($member_status == 'Active') ){ 

							//send warning email - Please don't forget to make your purchase
							$message = "Please don't forget to make your purchase";	
							$message .= "<br>you cannot earn rewards while being Inactive.<br> To fix the problem your minimum purchase is now R".(2 * $purchase_threshold_amount_P);		
							wp_mail($user_email, $subject, $message, $header);
				  	
							}else if($member_status == 'Inactive'){
							//send warning email - You are currently inactive, Please don't forget to double your purchase to become Active again
							$message = "You are currently inactive, Please don't forget to double your purchase to become Active again";	
							$message .= "<br>you cannot earn rewards while being Inactive.<br> To fix the problem your minimum purchase is now R".(2 * $purchase_threshold_amount_B);	
							wp_mail($user_email, $subject, $message, $header);			  	
							}
						}
/***********************************************************************************************************************/
					}
					break;
				case "B":
				$new_expiry_date = date('Y-m-d', strtotime($today. ' + '.(get_option("custom_profile_op_exp_date_B")-1).' days'));
					if( (strtotime($purchase_date) <= strtotime($expiry_date)) and ($diff <= get_option("custom_profile_op_exp_date_B")) and ($purchase_amount > $purchase_threshold_amount_B) ){
						if($member_status == 'Inactive'){
							$check = check_total_purchase_amount_B($all_orders);
							if($check == true){
							 update_user_meta($user_id, 'member_status','Active');
		 					 if(date('Y-m-d',strtotime($expiry_date. '+1 day')) == $today){
							 update_user_meta($user_id, 'expiry_date',$new_expiry_date);
							 }
							}
						}else{
							 update_user_meta($user_id, 'member_status','Active');
		 					 if(date('Y-m-d',strtotime($expiry_date. '+1 day')) == $today){
							 update_user_meta($user_id, 'expiry_date',$new_expiry_date);
							 }
						}						
					}else{
						if(date('Y-m-d',strtotime($expiry_date. '+1 day')) == $today){
							if( ($member_status == 'Qualified') or ($member_status == 'Active') ){
							update_user_meta($user_id, 'member_status','Inactive');
							update_user_meta($user_id, 'expiry_date',$new_expiry_date);
							//send email - You are currently inactive, Please don't forget to double your purchase to
							$message = "You are currently inactive, Please don't forget to double your purchase to become Active again";
							$message .= "<br>You cannot earn rewards while being Inactive.<br> To fix the problem your minimum purchase is now R".(2 * $purchase_threshold_amount_P);
							wp_mail($user_email, $subject, $message, $header);				  	
							}else if($member_status == 'Inactive'){
							update_user_meta($user_id, 'member_status','Terminated');
							update_user_meta($user_id, 'expiry_date','0');	
							// $message = "You have been terminated from our system, We are sorry to see you go, Thanks for your support";	
							//send email - Your membership has been terminated due to no activity for 3 months
							$message = "We regret to inform you that your account has been <strong>Terminated</strong> from our system.Your membership has been terminated due to no activity for 3 months. Your access has been blocked, and you won't be able to log in or make any purchases using this account.";							
							wp_mail($user_email, $subject, $message, $header);			  	
							}
						}
/**********************************************************************************************************************/
						if( (date('Y-m-d',strtotime($expiry_date. '-5 days')) == $today) or (date('Y-m-d',strtotime($expiry_date. '-3 days')) == $today)){
							if( ($member_status == 'Qualified') or ($member_status == 'Active') ){ 
							//send warning email - Please don't forget to make your purchase
							$message = "Please don't forget to make your purchase";	
							$message .= "<br>you cannot earn rewards while being Inactive.<br> To fix the problem your minimum purchase is now R".(2 * $purchase_threshold_amount_P);	
							wp_mail($user_email, $subject, $message, $header);
				  	
							}else if($member_status == 'Inactive'){ 
							//send warning email - You are currently inactive, Please don't forget to double your purchase to become Active again
							$message = "You are currently inactive, Please don't forget to double your purchase to become Active again";
							$message .= "<br>you cannot earn rewards while being Inactive.<br> To fix the problem your minimum purchase is now R".(2 * $purchase_threshold_amount_B);		
							wp_mail($user_email, $subject, $message, $header);			  	
							}
						}
						/*********************************************************************************************************************************************/
					}
					break;
				case "S":
				$new_expiry_date = date('Y-m-d', strtotime($today. ' + '.(get_option("custom_profile_op_exp_date_S")-1).' days'));
					if( (strtotime($purchase_date) <= strtotime($expiry_date) ) and ($diff <= get_option("custom_profile_op_exp_date_S")) ){
 						if(date('Y-m-d',strtotime($expiry_date. '+1 day')) == $today){
							update_user_meta($user_id, 'expiry_date',$new_expiry_date);
						}
					}else{
						if(date('Y-m-d',strtotime($expiry_date. '+1 day')) == $today){
							update_user_meta($user_id, 'customer_type','P');
							//$expiry_date_p = date('Y-m-d', strtotime($today. ' + '.get_option(custom_profile_op_exp_date_P).' days')); 		
							$expiry_date_p = date('Y-m-d', strtotime($today. ' + '.(get_option("custom_profile_op_exp_date_P")-1).' days'));	
							update_user_meta($user_id, 'expiry_date',$expiry_date_p);
						}
						/*********************************************************************************************************************************************/
						if( (date('Y-m-d',strtotime($expiry_date. '-5 days')) == $today) or (date('Y-m-d',strtotime($expiry_date. '-3 days')) == $today)){
							if( ($member_status == 'Qualified') or ($member_status == 'Active') ){ 

							//send warning email - Please don't forget to make your purchase
							$message = "Please don't forget to make your purchase";	
							$message .= "<br>you cannot earn rewards while being Inactive.<br> To fix the problem your minimum purchase is now R".(2 * $purchase_threshold_amount_P);		
							wp_mail($user_email, $subject, $message, $header);				  	
							}
						}
						/*********************************************************************************************************************************************/
					}
					break;

				case "U": 
				$new_expiry_date = date('Y-m-d', strtotime($today. ' + '.(get_option("custom_profile_op_exp_date_U")-1).' days'));
					if( (strtotime($purchase_date) <= strtotime($expiry_date) ) and ($diff <= get_option("custom_profile_op_exp_date_U")) ){
 						if($expiry_date == $today){
							update_user_meta($user_id, 'expiry_date',$new_expiry_date);
						}
					}else{
						if(date('Y-m-d',strtotime($expiry_date. '+1 day')) == $today){
							update_user_meta($user_id, 'customer_type','P');
							//$expiry_date_p = date('Y-m-d', strtotime($today. ' + '.get_option(custom_profile_op_exp_date_P).' days')); 	
							$expiry_date_p = date('Y-m-d', strtotime($today. ' + '.(get_option("custom_profile_op_exp_date_P")-1).' days'));			
							update_user_meta($user_id, 'expiry_date',$expiry_date_p);
						}
						/*********************************************************************************************************************************************/
						if( (date('Y-m-d',strtotime($expiry_date. '-5 days')) == $today) or (date('Y-m-d',strtotime($expiry_date. '-3 days')) == $today)){
							if( ($member_status == 'Qualified') or ($member_status == 'Active') ){
							//send warning email - Please don't forget to make your purchase
							$message = "Please don't forget to make your purchase";
							$message .= "<br>you cannot earn rewards while being Inactive.<br> To fix the problem your minimum purchase is now R".(2 * $purchase_threshold_amount_P);			
							mail($user_email, $subject, $message, $header);				  	
							}
						}
						/*********************************************************************************************************************************************/
					}
					break;
				default: break;		
			}
		}
		
	}
	endforeach;
}

function commission_update_cron_exec(){
		global $wpdb;
		$user_commission = array();
		// $from = date("Y-m-d H:i:s",strtotime("-1 month")); 
		// Example usage:
		$year = date('Y');
		$month = date('M');
		$lastDay = getLastDayOfMonth($year, $month);
		// echo $lastDay; // Output: 31
		$from = date("".$year."-".$month."-01 H:i:s");
		// $to = date("Y-m-d 23:59:59",strtotime($date. "-1 day"));
		$to = date("".$year."-".$month."-".$lastDay."23:59:59"); 
	
		foreach( $wpdb->get_results("SELECT ID, user_login, display_name FROM $wpdb->users ORDER BY ID") as $user ) :
			$user_id = $user->ID; 		
			if(get_user_meta($user_id,'member_status','true') == 'Active'){
				// $level1_count = get_level_1_users_count($user_id);
				$level1_count = get_level_1_users_count_report($user_id,$from,$to);		        
				$membership_level = explode(',',get_membership_level($level1_count));
				$ml_value = $membership_level[0];  
				$ml_key = $membership_level[1];
				//update membership level	
				update_user_meta($user_id,'membership_level',$ml_value);
				$all_level_users = get_all_level_users_start($user_id);
				$total_commission = get_total_commission($all_level_users,$user_id,$ml_key);

				$data = array('uc_user_id'=>$user_id,'uc_date'=>$current_date,'uc_membership_level'=>$ml_value,'uc_total_commission'=>$total_commission);
				array_push($user_commission,$data);
				$wpdb->insert( $wpdb->prefix.'user_commission',$data);	
				// create_xlsx_file($user_id , $from , $to , "cron");
			}
			// elseif(get_user_meta($user_id,'member_status','true') == 'Inactive'){
			
			// }
		endforeach;
			// create_commission_xlsx_file_report($user_id, "07/01/2023","08/31/2023","cron"); 
			create_commission_xlsx_file_report($user_id, $from,$to,"cron"); 
	}

function getLastDayOfMonth($year, $month) {
    // Set the date to the first day of the next month
    $firstDayOfNextMonth = date("Y-m-d", strtotime("$year-$month-01 +1 month"));
    // Subtract 1 day from the first day of the next month to get the last day of the current month
    $lastDayOfMonth = date("d", strtotime("$firstDayOfNextMonth -1 day"));
    return $lastDayOfMonth;
}

function get_total_commission($all_level_users,$user_id,$ml_key){ 
	$total_commission = 0;
	foreach($all_level_users as $user){		
		$level = get_level($user,$user_id,0,0);
		$from = date("Y-m-d H:i:s",strtotime("-1 month")); 
		$to = date("Y-m-d 23:59:59",strtotime($date. "-1 day")); 
		$amount_spent = get_amount_spent($user,$from,$to);  
		$level_percent = get_option("member_status_level_percentages");

		$percentage = $level_percent[$level-1][$level][$ml_key];
		$commission = round(($amount_spent*($percentage/100)),2);
		$total_commission += $commission;							
	}
	return $total_commission;
}

function check_total_purchase_amount_P($all_orders){
	$purchase_sum = 0;
	foreach($all_orders as $k=>$val){
    // print_r($all_orders);	
		$diff = ( (strtotime(get_user_meta($user_id,'expiry_date','true')) - strtotime($val))/(60 * 60 * 24) );
		if($diff < get_option("custom_profile_op_exp_date_P")){
			$latest_orders = new WC_Order( $k ); 
			$purchase_sum += number_format( (float) $latest_orders->get_total() -$latest_orders->get_total_tax() -$latest_orders->get_total_shipping() - $latest_orders->get_shipping_tax(), wc_get_price_decimals(), '.', '' );
		}
	}
	if($purchase_sum >= (2*$purchase_threshold_amount_P)){		
		return true;
	}
	return false;
}
function check_total_purchase_amount_B($all_orders){

	$purchase_sum = 0;
	foreach($all_orders as $k=>$val){
		$diff = ( (strtotime(get_user_meta($user_id,'expiry_date','true')) - strtotime($val))/(60 * 60 * 24) );
		if($diff < get_option("custom_profile_op_exp_date_B")){
			$latest_orders = new WC_Order( $k ); 
			$purchase_sum += number_format( (float) $latest_orders->get_total() -$latest_orders->get_total_tax() -$latest_orders->get_total_shipping() - $latest_orders->get_shipping_tax(), wc_get_price_decimals(), '.', '' );
		}
	}
	if($purchase_sum >= (2*$purchase_threshold_amount_P)){		
		return true;
	}
	return false;
}
// status_update_cron_exec();