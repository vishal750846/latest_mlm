<?php

class mlm_plugin_frontend
{

    public function __construct()
    {
        add_action( 'wp_enqueue_scripts' , array($this, 'init_wc_sdp'));
        add_shortcode('register_account', array($this,'my_custom_plugin_callback'));
    }
    public function init_wc_sdp(){

        wp_enqueue_script( 'mlm-ajax', 'https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js', array(), '1.0.0', true );
        wp_enqueue_script( 'mlm-validator', 'https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.5/jquery.validate.min.js', array(), '1.0.0', true );
        wp_enqueue_script( 'mlm-script',  MLM_PLUGIN_ASSETS_URL . 'js/frontend/script.js', array(), '1.0.0', true );
        wp_localize_script( 'mlm-script', 'frontendajax', array( 'ajaxurl' => admin_url( 'admin-ajax.php' )));
        wp_enqueue_style('mlm-style', MLM_PLUGIN_ASSETS_URL . 'css/frontend/style.css', array(), '0.1.0', 'all');
    }

    public function my_custom_plugin_callback(){ 
      require MLM_PLUGIN_INCLUDE_PATH . 'frontend/views/user_registration.php';
    }    
}

new mlm_plugin_frontend();

// https://gwcorp.co.za/gw

// https://gwcorp.co.za